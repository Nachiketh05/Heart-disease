function [riskScore, riskTier, details] = fuzzyLogicSystem(action, varargin)
% FUZZYLOGICSYSTEM Mamdani Fuzzy Inference Engine for Cardiovascular Risk.
%
%   Usage:
%       fis = fuzzyLogicSystem('build')
%       [riskScore, riskTier, details] = fuzzyLogicSystem('evaluate', fis, inputs)
%       details = fuzzyLogicSystem('explain', fis, singleInputVector)
%
%   Inputs for 'evaluate' / 'explain':
%       inputs - Matrix [N x 4] or Vector [1 x 4] of clinical variables:
%                [trestbps, chol, thalach, oldpeak]
%                - trestbps: Resting blood pressure (mm Hg, domain: 80 - 200)
%                - chol:     Serum cholesterol (mg/dL, domain: 120 - 570)
%                - thalach:  Maximum exercise heart rate (bpm, domain: 70 - 210)
%                - oldpeak:  ST depression induced by exercise (mm, domain: 0.0 - 6.2)
%
%   Outputs:
%       riskScore - Continuous defuzzified cardiovascular risk score [0 - 100%]
%       riskTier  - Linguistic risk category: 'Low Risk', 'Moderate Risk', 'High Risk', 'Critical Risk'
%       details   - Struct containing full intermediate calculations:
%                   antecedent memberships, rule firing strengths, clipped
%                   consequents, aggregated surface, centroid numerator/denominator.
%
%   Mathematical Rigor:
%       - Antecedent evaluation via triangular and shoulder-trapezoidal MFs
%       - Mamdani conjunction via Minimum T-norm: alpha_r = min(mu_1r, ..., mu_4r)
%       - Consequent implication via Mamdani minimum clipping: mu_Cr'(z) = min(alpha_r, mu_Cr(z))
%       - Rule aggregation via Maximum S-norm: mu_agg(z) = max_r(mu_Cr'(z))
%       - Defuzzification via Centroid (Center of Gravity): z* = sum(z * mu_agg) / sum(mu_agg)

    if nargin < 1
        action = 'build';
    end

    switch lower(action)
        case 'build'
            fis = buildFisModel();
            riskScore = fis;
            if nargout > 1, riskTier = ''; end
            if nargout > 2, details = struct(); end

        case 'evaluate'
            fis = varargin{1};
            inputs = varargin{2};
            [riskScore, riskTier, details] = evaluateFis(fis, inputs);

        case 'explain'
            fis = varargin{1};
            singleInput = varargin{2};
            [sc, tr, det] = evaluateFis(fis, singleInput(1, :));
            det.riskScore = sc;
            det.riskTier = tr;
            riskScore = det; % When called with 1 output: details = fuzzyLogicSystem('explain', ...)
            if nargout > 1, riskTier = sc; end
            if nargout > 2, details = tr; end

        otherwise
            error('Unknown action: %s. Valid actions: ''build'', ''evaluate'', ''explain''.', action);
    end
end

%% Internal Model Construction
function fis = buildFisModel()
    fis = struct();
    fis.name = 'Cleveland_Cardiac_Risk_FIS';
    fis.type = 'mamdani';

    % ---------------------------------------------------------------------
    % INPUT 1: trestbps (Resting Blood Pressure, mm Hg)
    % Domain: [80, 200]
    % Terms: Normal (Left-shoulder), Borderline (Triangular), Hypertensive (Right-shoulder)
    % ---------------------------------------------------------------------
    fis.inputs(1).name = 'trestbps';
    fis.inputs(1).range = [80, 200];
    fis.inputs(1).mfs(1).name = 'Normal';
    fis.inputs(1).mfs(1).type = 'trapmf';
    fis.inputs(1).mfs(1).params = [-inf, -inf, 115, 130]; % Left-shoulder: full 1 below 115, declines to 130

    fis.inputs(1).mfs(2).name = 'Borderline';
    fis.inputs(1).mfs(2).type = 'trimf';
    fis.inputs(1).mfs(2).params = [120, 135, 148];

    fis.inputs(1).mfs(3).name = 'Hypertensive';
    fis.inputs(1).mfs(3).type = 'trapmf';
    fis.inputs(1).mfs(3).params = [140, 160, inf, inf]; % Right-shoulder: rises from 140, full 1 at >=160

    % ---------------------------------------------------------------------
    % INPUT 2: chol (Serum Cholesterol, mg/dL)
    % Domain: [120, 570]
    % Terms: Desirable (Left-shoulder), Borderline (Triangular), Hypercholesterolemia (Right-shoulder)
    % ---------------------------------------------------------------------
    fis.inputs(2).name = 'chol';
    fis.inputs(2).range = [120, 570];
    fis.inputs(2).mfs(1).name = 'Desirable';
    fis.inputs(2).mfs(1).type = 'trapmf';
    fis.inputs(2).mfs(1).params = [-inf, -inf, 180, 205];

    fis.inputs(2).mfs(2).name = 'Borderline';
    fis.inputs(2).mfs(2).type = 'trimf';
    fis.inputs(2).mfs(2).params = [195, 225, 245];

    fis.inputs(2).mfs(3).name = 'Hyperchol';
    fis.inputs(2).mfs(3).type = 'trapmf';
    fis.inputs(2).mfs(3).params = [235, 275, inf, inf];

    % ---------------------------------------------------------------------
    % INPUT 3: thalach (Maximum Heart Rate Achieved, bpm)
    % Domain: [70, 210]
    % Terms: Impaired (Left-shoulder), Submaximal (Triangular), Normal (Right-shoulder)
    % ---------------------------------------------------------------------
    fis.inputs(3).name = 'thalach';
    fis.inputs(3).range = [70, 210];
    fis.inputs(3).mfs(1).name = 'Impaired';
    fis.inputs(3).mfs(1).type = 'trapmf';
    fis.inputs(3).mfs(1).params = [-inf, -inf, 100, 125];

    fis.inputs(3).mfs(2).name = 'Submaximal';
    fis.inputs(3).mfs(2).type = 'trimf';
    fis.inputs(3).mfs(2).params = [115, 140, 160];

    fis.inputs(3).mfs(3).name = 'Normal';
    fis.inputs(3).mfs(3).type = 'trapmf';
    fis.inputs(3).mfs(3).params = [150, 175, inf, inf];

    % ---------------------------------------------------------------------
    % INPUT 4: oldpeak (ST Depression Induced by Exercise, mm)
    % Domain: [0.0, 6.2]
    % Terms: Normal (Left-shoulder), MildIschemia (Triangular), SevereInjury (Right-shoulder)
    % ---------------------------------------------------------------------
    fis.inputs(4).name = 'oldpeak';
    fis.inputs(4).range = [0.0, 6.2];
    fis.inputs(4).mfs(1).name = 'Normal';
    fis.inputs(4).mfs(1).type = 'trapmf';
    fis.inputs(4).mfs(1).params = [-inf, -inf, 0.4, 1.0];

    fis.inputs(4).mfs(2).name = 'MildIschemia';
    fis.inputs(4).mfs(2).type = 'trimf';
    fis.inputs(4).mfs(2).params = [0.8, 1.5, 2.3];

    fis.inputs(4).mfs(3).name = 'SevereInjury';
    fis.inputs(4).mfs(3).type = 'trapmf';
    fis.inputs(4).mfs(3).params = [2.0, 3.2, inf, inf];

    % ---------------------------------------------------------------------
    % OUTPUT: Cardiovascular Risk Score [0 - 100%]
    % Terms: Low (1), Moderate (2), High (3), Critical (4)
    % ---------------------------------------------------------------------
    fis.output.name = 'Cardiovascular_Risk';
    fis.output.range = [0, 100];
    fis.output.mfs(1).name = 'Low';
    fis.output.mfs(1).type = 'trapmf';
    fis.output.mfs(1).params = [-inf, 0, 15, 30];

    fis.output.mfs(2).name = 'Moderate';
    fis.output.mfs(2).type = 'trimf';
    fis.output.mfs(2).params = [25, 45, 60];

    fis.output.mfs(3).name = 'High';
    fis.output.mfs(3).type = 'trimf';
    fis.output.mfs(3).params = [50, 70, 85];

    fis.output.mfs(4).name = 'Critical';
    fis.output.mfs(4).type = 'trapmf';
    fis.output.mfs(4).params = [75, 90, 100, inf];

    % ---------------------------------------------------------------------
    % Comprehensive Clinical Rule Base (All 3^4 = 81 Combinations)
    % Guarantees complete semantic coverage across continuous input space.
    % Columns: [trestbps_term, chol_term, thalach_term, oldpeak_term, output_term]
    % Severity indexing:
    %   s1 = term1 - 1 (BP: 0, 1, 2)
    %   s2 = term2 - 1 (Chol: 0, 1, 2)
    %   s3 = 3 - term3 (HR: 2 for Impaired, 1 for Submax, 0 for Normal)
    %   s4 = term4 - 1 (ST: 0 for Normal, 1 for Mild, 2 for Severe)
    % Total Severity Index: S = s1 + s2 + s3 + 2*s4 (Range: 0 to 8)
    % Mapping to output linguistic terms:
    %   S <= 1  -> Low Risk (1)
    %   S 2..3  -> Moderate Risk (2)
    %   S 4..5  -> High Risk (3)
    %   S >= 6  -> Critical Risk (4)
    % ---------------------------------------------------------------------
    rules = zeros(81, 5);
    ruleDescriptions = cell(81, 1);
    outNames = {'Low Risk', 'Moderate Risk', 'High Risk', 'Critical Risk'};
    bpNames   = {'Normal', 'Borderline', 'Hypertensive'};
    cholNames = {'Desirable', 'Borderline', 'Hyperchol'};
    hrNames   = {'Impaired', 'Submaximal', 'Normal'};
    stNames   = {'Normal', 'MildIschemia', 'SevereInjury'};

    rIdx = 0;
    for t1 = 1:3
        for t2 = 1:3
            for t3 = 1:3
                for t4 = 1:3
                    rIdx = rIdx + 1;
                    s1 = t1 - 1;
                    s2 = t2 - 1;
                    s3 = 3 - t3;
                    s4 = t4 - 1;
                    S = s1 + s2 + s3 + 2 * s4;

                    if S <= 1
                        outTerm = 1;
                    elseif S <= 3
                        outTerm = 2;
                    elseif S <= 5
                        outTerm = 3;
                    else
                        outTerm = 4;
                    end

                    rules(rIdx, :) = [t1, t2, t3, t4, outTerm];
                    ruleDescriptions{rIdx} = sprintf('IF BP is %s & Chol is %s & HR is %s & ST is %s THEN Risk is %s', ...
                        bpNames{t1}, cholNames{t2}, hrNames{t3}, stNames{t4}, outNames{outTerm});
                end
            end
        end
    end

    fis.rules = rules;
    fis.ruleDescriptions = ruleDescriptions;
end

%% Evaluation Engine with Full Intermediate Traceability
function [riskScore, riskTier, details] = evaluateFis(fis, inputs)
    nSamples = size(inputs, 1);
    riskScore = zeros(nSamples, 1);
    riskTier = cell(nSamples, 1);

    % Discrete output universe of discourse for numerical Centroid defuzzification
    % 501 points over [0, 100] provides step size dz = 0.2%
    y_universe = linspace(0, 100, 501);
    dz = y_universe(2) - y_universe(1);

    % Pre-compute consequent membership curves for output terms
    nOutTerms = numel(fis.output.mfs);
    consequentCurves = zeros(nOutTerms, numel(y_universe));
    for t = 1:nOutTerms
        consequentCurves(t, :) = evalMf(y_universe, fis.output.mfs(t).type, fis.output.mfs(t).params);
    end

    nRules = size(fis.rules, 1);

    % Intermediate records for single sample or cohort
    allMemberships = cell(nSamples, 1);
    allFiringStrengths = zeros(nSamples, nRules);
    allCentroidNum = zeros(nSamples, 1);
    allCentroidDen = zeros(nSamples, 1);
    allMuAgg = zeros(nSamples, numel(y_universe));

    for s = 1:nSamples
        u = inputs(s, :);

        % -----------------------------------------------------------------
        % Step 1: Antecedent Membership Degrees mu(x_j)
        % -----------------------------------------------------------------
        % Input 1: trestbps
        mu_in1 = [evalMf(u(1), fis.inputs(1).mfs(1).type, fis.inputs(1).mfs(1).params), ...
                  evalMf(u(1), fis.inputs(1).mfs(2).type, fis.inputs(1).mfs(2).params), ...
                  evalMf(u(1), fis.inputs(1).mfs(3).type, fis.inputs(1).mfs(3).params)];
        % Input 2: chol
        mu_in2 = [evalMf(u(2), fis.inputs(2).mfs(1).type, fis.inputs(2).mfs(1).params), ...
                  evalMf(u(2), fis.inputs(2).mfs(2).type, fis.inputs(2).mfs(2).params), ...
                  evalMf(u(2), fis.inputs(2).mfs(3).type, fis.inputs(2).mfs(3).params)];
        % Input 3: thalach
        mu_in3 = [evalMf(u(3), fis.inputs(3).mfs(1).type, fis.inputs(3).mfs(1).params), ...
                  evalMf(u(3), fis.inputs(3).mfs(2).type, fis.inputs(3).mfs(2).params), ...
                  evalMf(u(3), fis.inputs(3).mfs(3).type, fis.inputs(3).mfs(3).params)];
        % Input 4: oldpeak
        mu_in4 = [evalMf(u(4), fis.inputs(4).mfs(1).type, fis.inputs(4).mfs(1).params), ...
                  evalMf(u(4), fis.inputs(4).mfs(2).type, fis.inputs(4).mfs(2).params), ...
                  evalMf(u(4), fis.inputs(4).mfs(3).type, fis.inputs(4).mfs(3).params)];

        allMemberships{s} = struct('trestbps', mu_in1, 'chol', mu_in2, ...
                                   'thalach', mu_in3, 'oldpeak', mu_in4);

        % -----------------------------------------------------------------
        % Step 2: Rule Firing Strengths (Mamdani Min T-norm)
        % alpha_r = min(mu_1, mu_2, mu_3, mu_4)
        % -----------------------------------------------------------------
        firing = zeros(nRules, 1);
        clippedConsequents = zeros(nRules, numel(y_universe));

        for r = 1:nRules
            i1 = fis.rules(r, 1);
            i2 = fis.rules(r, 2);
            i3 = fis.rules(r, 3);
            i4 = fis.rules(r, 4);
            outTerm = fis.rules(r, 5);

            alpha_r = min([mu_in1(i1), mu_in2(i2), mu_in3(i3), mu_in4(i4)]);
            firing(r) = alpha_r;

            % Step 3: Consequent Implication (Minimum Clipping)
            if alpha_r > 0
                clippedConsequents(r, :) = min(alpha_r, consequentCurves(outTerm, :));
            end
        end
        allFiringStrengths(s, :) = firing';

        % -----------------------------------------------------------------
        % Step 4: Rule Aggregation (Maximum S-norm)
        % mu_agg(z) = max_r( clipped_r(z) )
        % -----------------------------------------------------------------
        if any(firing > 0)
            mu_agg = max(clippedConsequents, [], 1);
        else
            % Fallback: If no rule fires (extreme outlier), compute proportional membership
            mu_agg = ones(size(y_universe)) * 0.1;
        end
        allMuAgg(s, :) = mu_agg;

        % -----------------------------------------------------------------
        % Step 5: Defuzzification (Centroid / Center of Gravity)
        % z* = sum( z * mu_agg(z) * dz ) / sum( mu_agg(z) * dz )
        % -----------------------------------------------------------------
        numerator = sum(y_universe .* mu_agg * dz);
        denominator = sum(mu_agg * dz);

        allCentroidNum(s) = numerator;
        allCentroidDen(s) = denominator;

        if denominator > 1e-9
            cog = numerator / denominator;
        else
            cog = 50.0; % Neutral risk fallback
        end

        riskScore(s) = cog;

        % Linguistic risk categorization
        if cog < 30.0
            riskTier{s} = 'Low Risk';
        elseif cog < 60.0
            riskTier{s} = 'Moderate Risk';
        elseif cog < 80.0
            riskTier{s} = 'High Risk';
        else
            riskTier{s} = 'Critical Risk';
        end
    end

    % Populate comprehensive details struct
    details = struct();
    details.y_universe = y_universe;
    details.dz = dz;
    details.consequentCurves = consequentCurves;
    details.allMemberships = allMemberships;
    details.firingStrengths = allFiringStrengths;
    details.ruleDescriptions = fis.ruleDescriptions;
    details.centroidNumerator = allCentroidNum;
    details.centroidDenominator = allCentroidDen;
    details.mu_agg = allMuAgg;

    % For single patient convenience: expose direct fields
    if nSamples == 1
        details.last_mu_in1 = allMemberships{1}.trestbps;
        details.last_mu_in2 = allMemberships{1}.chol;
        details.last_mu_in3 = allMemberships{1}.thalach;
        details.last_mu_in4 = allMemberships{1}.oldpeak;
        details.last_firing = allFiringStrengths(1, :)';
        details.last_mu_agg = allMuAgg(1, :);
        details.last_cog_num = allCentroidNum(1);
        details.last_cog_den = allCentroidDen(1);
        details.activeRules = find(details.last_firing > 0);
    end
end

%% Generalized Membership Function Evaluator
function mu = evalMf(x, mfType, params)
    switch lower(mfType)
        case 'trimf'
            mu = trimf_calc(x, params);
        case 'trapmf'
            mu = trapmf_calc(x, params);
        otherwise
            error('Unsupported membership function type: %s', mfType);
    end
end

%% Triangular Membership Formula
%  params = [a, b, c]
function mu = trimf_calc(x, p)
    a = p(1); b = p(2); c = p(3);
    mu = zeros(size(x));

    % Left slope: (x - a) / (b - a)
    idx1 = (x >= a) & (x < b);
    if b > a
        mu(idx1) = (x(idx1) - a) / (b - a);
    end

    % Right slope: (c - x) / (c - b)
    idx2 = (x >= b) & (x <= c);
    if c > b
        mu(idx2) = (c - x(idx2)) / (c - b);
    end

    % Peak
    mu(x == b) = 1.0;
    % Bounds
    mu(x < a | x > c) = 0.0;
end

%% Trapezoidal Membership Formula (Supports Left & Right Shoulders)
%  params = [a, b, c, d]
function mu = trapmf_calc(x, p)
    a = p(1); b = p(2); c = p(3); d = p(4);
    mu = zeros(size(x));

    % Case 1: Left shoulder (a = -inf, b = -inf)
    if isinf(a) && a < 0 && isinf(b) && b < 0
        mu(x <= c) = 1.0;
        idx = (x > c) & (x <= d);
        if d > c
            mu(idx) = (d - x(idx)) / (d - c);
        end
        mu(x > d) = 0.0;
        return;
    end

    % Case 2: Right shoulder (c = inf, d = inf)
    if isinf(c) && c > 0 && isinf(d) && d > 0
        mu(x < a) = 0.0;
        idx = (x >= a) & (x < b);
        if b > a
            mu(idx) = (x(idx) - a) / (b - a);
        end
        mu(x >= b) = 1.0;
        return;
    end

    % Case 3: Standard trapezoid
    idx1 = (x >= a) & (x < b);
    if b > a
        mu(idx1) = (x(idx1) - a) / (b - a);
    end

    idxPlateau = (x >= b) & (x <= c);
    mu(idxPlateau) = 1.0;

    idx2 = (x > c) & (x <= d);
    if d > c
        mu(idx2) = (d - x(idx2)) / (d - c);
    end

    mu(x < a | x > d) = 0.0;
end
