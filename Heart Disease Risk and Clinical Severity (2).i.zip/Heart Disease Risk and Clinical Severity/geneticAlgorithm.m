function gaResult = geneticAlgorithm(X_train, y_train, X_val, y_val, gaOpts)
% GENETICALGORITHM Stochastic 13-bit binary wrapper feature selection.
%
%   gaResult = geneticAlgorithm(X_train, y_train, X_val, y_val, gaOpts)
%
%   Inputs:
%       X_train, y_train - Training feature matrix [N x 20] and labels (0 to 4)
%       X_val, y_val     - Validation feature matrix [N_val x 20] and labels (0 to 4)
%       gaOpts           - Optional hyperparameter struct:
%                          .popSize     (default: 30)
%                          .generations (default: 35)
%                          .pCrossover  (default: 0.85)
%                          .pMutation   (default: 1/13)
%                          .tournamentK (default: 3)
%                          .elites      (default: 2)
%                          .verbose     (default: true)
%
%   Outputs:
%       gaResult - Struct containing:
%                  .bestChromosome         - 13-bit binary vector
%                  .selectedRawFeatures    - Indices [1..13] of chosen attributes
%                  .selectedFeatureNames   - Cell array of selected clinical names
%                  .selectedEncodedColumns - Indices [1..20] in preprocessed matrix
%                  .numSelectedFeatures    - Count of active raw features
%                  .bestFitness            - Maximum validation fitness achieved
%                  .valMacroF1             - Validation Macro-F1 of best subset
%                  .fitnessHistory         - Generation best fitness vector
%                  .meanFitnessHistory     - Generation mean fitness vector
%                  .worstFitnessHistory    - Generation worst fitness vector
%                  .generationLog          - Struct array of generation metrics
%                  .allFeaturesBaseline    - Struct with baseline all-feature metrics
%
%   Academic Context:
%       Optimizes biomarker selection by exploring the 2^13 = 8,192 combinatorial
%       subsets of Cleveland clinical features. Maximizes validation Macro-F1
%       while penalizing clinical test burden (feature cardinality).
%       OPTIMIZED STRICTLY ON VALIDATION DATA (NEVER TOUCHES TEST DATA).

    if nargin < 5 || isempty(gaOpts)
        gaOpts = struct();
    end

    % 13 Raw Cleveland Clinical Attributes
    rawFeatureNames = {
        'age', ...      % 1: Age (continuous) -> col 1
        'trestbps', ... % 2: Resting BP (continuous) -> col 2
        'chol', ...     % 3: Cholesterol (continuous) -> col 3
        'thalach', ...  % 4: Max HR (continuous) -> col 4
        'oldpeak', ...  % 5: ST Depression (continuous) -> col 5
        'sex', ...      % 6: Sex (binary) -> col 6
        'fbs', ...      % 7: Fasting Blood Sugar (binary) -> col 7
        'exang', ...    % 8: Exercise Angina (binary) -> col 8
        'slope', ...    % 9: ST Slope (ordinal) -> col 9
        'ca', ...       % 10: Fluoroscopy Vessels (ordinal) -> col 10
        'cp', ...       % 11: Chest Pain Type (nominal 4-level) -> cols 11:14
        'restecg', ...  % 12: Resting ECG (nominal 3-level) -> cols 15:17
        'thal' ...      % 13: Thallium Scan (nominal 3-level) -> cols 18:20
    };

    numRawGenes = 13;

    % Hyperparameters
    popSize     = getFieldOrDefault(gaOpts, 'popSize', 30);
    generations = getFieldOrDefault(gaOpts, 'generations', 35);
    pCrossover  = getFieldOrDefault(gaOpts, 'pCrossover', 0.85);
    pMutation   = getFieldOrDefault(gaOpts, 'pMutation', 1.0 / numRawGenes);
    tournamentK = getFieldOrDefault(gaOpts, 'tournamentK', 3);
    elites      = getFieldOrDefault(gaOpts, 'elites', 2);
    verbose     = getFieldOrDefault(gaOpts, 'verbose', true);

    % Compute baseline metrics with all 13 features active
    allFeaturesMask = true(1, numRawGenes);
    allCols = mapGenesToColumns(allFeaturesMask);
    [baseF1, basePred] = evaluateValidationSurrogate(X_train(:, allCols), y_train, X_val(:, allCols), y_val);
    baseFitness = 0.85 * baseF1 - 0.15 * (numRawGenes / numRawGenes);

    allFeaturesBaseline = struct();
    allFeaturesBaseline.chromosome = allFeaturesMask;
    allFeaturesBaseline.numFeatures = numRawGenes;
    allFeaturesBaseline.valMacroF1 = baseF1;
    allFeaturesBaseline.fitness = baseFitness;

    % Population initialization: uniformly random {0, 1}^13
    rng(42); % Reproducible initialization
    pop = rand(popSize, numRawGenes) > 0.5;
    % Ensure no chromosome has zero active features
    for i = 1:popSize
        if sum(pop(i, :)) == 0
            pop(i, randi(numRawGenes)) = true;
        end
    end

    fitnessHistory      = zeros(generations, 1);
    meanFitnessHistory  = zeros(generations, 1);
    worstFitnessHistory = zeros(generations, 1);
    generationLog       = repmat(struct('gen', 0, 'bestFit', 0, 'meanFit', 0, ...
                                        'worstFit', 0, 'activeFeatures', 0, ...
                                        'valMacroF1', 0), generations, 1);

    bestFitness = -inf;
    bestChromosome = pop(1, :);
    bestValF1 = 0;

    if verbose
        fprintf('[GA] 13-Gene Binary Clinical Feature Optimization Started:\n');
        fprintf('     Population: %d | Generations: %d | Mutation Rate: %.4f\n', ...
                popSize, generations, pMutation);
        fprintf('     Baseline (All 13 Features): Val Macro-F1 = %.4f | Fitness = %.4f\n', ...
                baseF1, baseFitness);
    end

    % Evolutionary Generations
    for gen = 1:generations
        fitness = zeros(popSize, 1);
        f1Values = zeros(popSize, 1);

        for i = 1:popSize
            mask13 = pop(i, :);
            activeCount = sum(mask13);

            if activeCount == 0
                fitness(i) = -10.0; % Harsh penalty for null model
                continue;
            end

            % Map 13 active clinical genes to preprocessed matrix column indices
            encodedCols = mapGenesToColumns(mask13);

            % Evaluate strictly on validation fold using fast multiclass surrogate
            f1_val = evaluateValidationSurrogate(X_train(:, encodedCols), y_train, ...
                                                X_val(:, encodedCols), y_val);
            f1Values(i) = f1_val;

            % Multi-Objective Fitness: Maximize validation Macro-F1, penalize feature density
            cardinalityRatio = activeCount / numRawGenes;
            fitness(i) = 0.85 * f1_val - 0.15 * cardinalityRatio;
        end

        % Generation statistics
        [genBestFit, genBestIdx] = max(fitness);
        genMeanFit = mean(fitness);
        genWorstFit = min(fitness);

        fitnessHistory(gen)      = genBestFit;
        meanFitnessHistory(gen)  = genMeanFit;
        worstFitnessHistory(gen) = genWorstFit;

        if genBestFit > bestFitness
            bestFitness    = genBestFit;
            bestChromosome = pop(genBestIdx, :);
            bestValF1      = f1Values(genBestIdx);
        end

        generationLog(gen).gen = gen;
        generationLog(gen).bestFit = genBestFit;
        generationLog(gen).meanFit = genMeanFit;
        generationLog(gen).worstFit = genWorstFit;
        generationLog(gen).activeFeatures = sum(bestChromosome);
        generationLog(gen).valMacroF1 = bestValF1;

        if verbose && (gen == 1 || mod(gen, 10) == 0 || gen == generations)
            fprintf('  [Gen %2d/%2d] Best Fit: %.4f | Mean: %.4f | Active: %2d/13 | Val F1: %.4f\n', ...
                    gen, generations, genBestFit, genMeanFit, sum(bestChromosome), bestValF1);
        end

        % Elitism: Retain top E chromosomes
        [~, sortIdx] = sort(fitness, 'descend');
        newPop = pop(sortIdx(1:elites), :);

        % Offspring Generation via Tournament Selection, Crossover & Mutation
        while size(newPop, 1) < popSize
            p1 = tournamentSelect(pop, fitness, tournamentK);
            p2 = tournamentSelect(pop, fitness, tournamentK);

            % Uniform Crossover
            if rand() < pCrossover
                crossMask = rand(1, numRawGenes) > 0.5;
                c1 = p1; c1(crossMask) = p2(crossMask);
                c2 = p2; c2(crossMask) = p1(crossMask);
            else
                c1 = p1;
                c2 = p2;
            end

            % Bit-Flip Mutation (Bernoulli trial per gene)
            mutMask1 = rand(1, numRawGenes) < pMutation;
            c1(mutMask1) = ~c1(mutMask1);
            mutMask2 = rand(1, numRawGenes) < pMutation;
            c2(mutMask2) = ~c2(mutMask2);

            % Guarantee non-empty feature subsets
            if sum(c1) == 0, c1(randi(numRawGenes)) = true; end
            if sum(c2) == 0, c2(randi(numRawGenes)) = true; end

            newPop = [newPop; c1; c2];
        end

        pop = newPop(1:popSize, :);
    end

    selectedRawIndices = find(bestChromosome);
    selectedCols = mapGenesToColumns(bestChromosome);

    gaResult = struct();
    gaResult.bestChromosome         = bestChromosome;
    gaResult.selectedRawFeatures    = selectedRawIndices;
    gaResult.selectedFeatureNames   = rawFeatureNames(selectedRawIndices);
    gaResult.selectedEncodedColumns = selectedCols;
    gaResult.numSelectedFeatures    = numel(selectedRawIndices);
    gaResult.bestFitness            = bestFitness;
    gaResult.valMacroF1             = bestValF1;
    gaResult.fitnessHistory         = fitnessHistory;
    gaResult.meanFitnessHistory     = meanFitnessHistory;
    gaResult.worstFitnessHistory    = worstFitnessHistory;
    gaResult.generationLog          = generationLog;
    gaResult.allFeaturesBaseline    = allFeaturesBaseline;

    if verbose
        fprintf('[GA] Optimization Concluded.\n');
        fprintf('     Selected %d / 13 clinical attributes: [ %s]\n', ...
                gaResult.numSelectedFeatures, sprintf('%s ', gaResult.selectedFeatureNames{:}));
        fprintf('     Validation Macro-F1: %.4f (Baseline: %.4f, Delta: %+0.4f)\n', ...
                bestValF1, baseF1, bestValF1 - baseF1);
    end
end

%% Gene-to-Column Mapping Engine
% Maps 13 binary clinical genes to corresponding preprocessed matrix columns
function cols = mapGenesToColumns(genes13)
    % Column definition in preprocessed matrix:
    % 1: age (col 1)
    % 2: trestbps (col 2)
    % 3: chol (col 3)
    % 4: thalach (col 4)
    % 5: oldpeak (col 5)
    % 6: sex (col 6)
    % 7: fbs (col 7)
    % 8: exang (col 8)
    % 9: slope (col 9)
    % 10: ca (col 10)
    % 11: cp (cols 11, 12, 13, 14 - one-hot)
    % 12: restecg (cols 15, 16, 17 - one-hot)
    % 13: thal (cols 18, 19, 20 - one-hot)
    geneColMap = {
        1;           % 1: age
        2;           % 2: trestbps
        3;           % 3: chol
        4;           % 4: thalach
        5;           % 5: oldpeak
        6;           % 6: sex
        7;           % 7: fbs
        8;           % 8: exang
        9;           % 9: slope
        10;          % 10: ca
        [11, 12, 13, 14]; % 11: cp
        [15, 16, 17];     % 12: restecg
        [18, 19, 20]      % 13: thal
    };

    activeGenes = find(genes13);
    colCell = geneColMap(activeGenes);
    cols = [colCell{:}];
end

%% Tournament Selection Operator
function winner = tournamentSelect(pop, fitness, k)
    popSize = size(pop, 1);
    candidates = randi(popSize, [k, 1]);
    [~, bestInTour] = max(fitness(candidates));
    winner = pop(candidates(bestInTour), :);
end

%% Fast Multiclass Validation Surrogate
% Evaluates candidate feature subsets strictly on validation data
function [macroF1, y_pred] = evaluateValidationSurrogate(X_tr, y_tr, X_va, y_va)
    classes = 0:4;
    numC = numel(classes);
    D = size(X_tr, 2);

    % Compute class centroids with ridge regularization
    centroids = zeros(numC, D);
    for c = 1:numC
        idx = (y_tr == classes(c));
        if any(idx)
            centroids(c, :) = mean(X_tr(idx, :), 1);
        else
            centroids(c, :) = zeros(1, D);
        end
    end

    % Nearest Centroid Euclidean Distance Assignment
    N_va = size(X_va, 1);
    dists = zeros(N_va, numC);
    for c = 1:numC
        diff = X_va - repmat(centroids(c, :), N_va, 1);
        dists(:, c) = sum(diff .^ 2, 2);
    end

    [~, minIdx] = min(dists, [], 2);
    y_pred = minIdx - 1; % Convert to 0-4

    % Macro-F1 with division-by-zero safeguards
    f1s = zeros(numC, 1);
    for c = 1:numC
        target = classes(c);
        tp = sum(y_va == target & y_pred == target);
        fp = sum(y_va ~= target & y_pred == target);
        fn = sum(y_va == target & y_pred ~= target);

        if (2 * tp + fp + fn) > 0
            f1s(c) = (2.0 * tp) / (2.0 * tp + fp + fn);
        else
            f1s(c) = 0.0;
        end
    end

    macroF1 = mean(f1s);
end

function val = getFieldOrDefault(s, field, defaultVal)
    if isfield(s, field)
        val = s.(field);
    else
        val = defaultVal;
    end
end
