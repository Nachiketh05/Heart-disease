import matplotlib.pyplot as plt
import matplotlib.patches as patches
from matplotlib.patches import FancyBboxPatch, FancyArrowPatch
import numpy as np
import os

# Set Matplotlib temp cache directory to avoid warning
os.environ['MPLCONFIGDIR'] = os.path.join(os.getcwd(), '.matplotlib_cache')
os.makedirs(os.environ['MPLCONFIGDIR'], exist_ok=True)

# Set figure parameters for high-resolution publication quality
plt.rcParams['font.family'] = 'DejaVu Sans'
plt.rcParams['font.size'] = 10
plt.rcParams['axes.edgecolor'] = '#333333'
plt.rcParams['axes.linewidth'] = 0.8

fig = plt.figure(figsize=(24, 15), dpi=300, facecolor='#F8FAFC')
ax = fig.add_subplot(111)
ax.set_xlim(0, 100)
ax.set_ylim(0, 100)
ax.axis('off')

# Color Palette - Professional Academic / Medical Theme
NAVY_DARK    = '#0F172A'
SLATE_BORDER = '#334155'
CARD_BG      = '#FFFFFF'
SECTION_BG   = '#F1F5F9'

# Module specific accent palettes
CLR_INPUT    = {'header': '#0284C7', 'sub': '#E0F2FE', 'border': '#0284C7', 'text': '#0369A1'} # Sky/Blue
CLR_PREP     = {'header': '#475569', 'sub': '#F1F5F9', 'border': '#64748B', 'text': '#1E293B'} # Slate
CLR_MLP      = {'header': '#1E40AF', 'sub': '#EFF6FF', 'border': '#2563EB', 'text': '#1E3A8A'} # Deep Blue
CLR_HOPFIELD = {'header': '#0D9488', 'sub': '#F0FDFA', 'border': '#14B8A6', 'text': '#0F766E'} # Teal
CLR_FUZZY    = {'header': '#B45309', 'sub': '#FFFBEB', 'border': '#D97706', 'text': '#92400E'} # Amber/Orange
CLR_GA       = {'header': '#4F46E5', 'sub': '#EEF2FF', 'border': '#6366F1', 'text': '#3730A3'} # Indigo
CLR_FUSION   = {'header': '#BE123C', 'sub': '#FFF1F2', 'border': '#E11D48', 'text': '#9F1239'} # Rose/Crimson
CLR_EVAL     = {'header': '#047857', 'sub': '#ECFDF5', 'border': '#059669', 'text': '#065F46'} # Emerald

def draw_header_card(ax, x, y, w, h, title, subtitle, palette, corner_radius=1.2):
    # Base container card
    base = FancyBboxPatch((x, y), w, h, boxstyle=f"round,pad=0,rounding_size={corner_radius}",
                          facecolor=CARD_BG, edgecolor=palette['border'], linewidth=1.6, zorder=2)
    ax.add_patch(base)
    
    # Header banner
    header_h = h * 0.22
    header = FancyBboxPatch((x, y + h - header_h), w, header_h, 
                            boxstyle=f"round,pad=0,rounding_size={corner_radius}",
                            facecolor=palette['header'], edgecolor=palette['header'], linewidth=1, zorder=3)
    ax.add_patch(header)
    
    # Straight bottom for the header to neatly merge
    rect_fix = patches.Rectangle((x, y + h - header_h), w, header_h * 0.4, 
                                 facecolor=palette['header'], edgecolor=palette['header'], zorder=3)
    ax.add_patch(rect_fix)
    
    # Header title text
    ax.text(x + w/2, y + h - (header_h * 0.42), title, ha='center', va='center',
            color='#FFFFFF', fontsize=11, fontweight='bold', zorder=4)
    if subtitle:
        ax.text(x + w/2, y + h - (header_h * 0.78), subtitle, ha='center', va='center',
                color='#E2E8F0', fontsize=8.5, fontstyle='italic', zorder=4)

def draw_pill(ax, x, y, w, h, text, color_bg, color_border, text_color='#1E293B', fontsize=8, bold=False):
    pill = FancyBboxPatch((x, y), w, h, boxstyle="round,pad=0.2,rounding_size=0.6",
                          facecolor=color_bg, edgecolor=color_border, linewidth=1.0, zorder=4)
    ax.add_patch(pill)
    fw = 'bold' if bold else 'normal'
    ax.text(x + w/2, y + h/2, text, ha='center', va='center', color=text_color, fontsize=fontsize, fontweight=fw, zorder=5)

def draw_arrow(ax, start, end, label='', color='#475569', rad=0.0, lw=2.0, style='-|>', ls='-'):
    arrow = FancyArrowPatch(start, end,
                            connectionstyle=f"arc3,rad={rad}",
                            arrowstyle=f"{style},head_length=6,head_width=4",
                            linewidth=lw, color=color, linestyle=ls, zorder=6)
    ax.add_patch(arrow)
    if label:
        mx = (start[0] + end[0]) / 2
        my = (start[1] + end[1]) / 2 + (1.2 if rad == 0 else (rad * 4))
        ax.text(mx, my, label, ha='center', va='center', fontsize=8.5, fontweight='bold',
                color=color, bbox=dict(boxstyle="round,pad=0.2", fc="#FFFFFF", ec=color, lw=0.8, alpha=0.9), zorder=7)

# ==========================================
# 0. MAIN TITLE & ARCHITECTURE HEADER BANNER
# ==========================================
title_bg = FancyBboxPatch((2, 92.5), 96, 6.2, boxstyle="round,pad=0,rounding_size=1.0",
                          facecolor=NAVY_DARK, edgecolor=SLATE_BORDER, linewidth=1.5, zorder=2)
ax.add_patch(title_bg)
ax.text(50, 96.2, "INTEGRATED COMPUTATIONAL INTELLIGENCE SYSTEM ARCHITECTURE", 
        ha='center', va='center', color='#FFFFFF', fontsize=18, fontweight='bold', zorder=4)
ax.text(50, 93.8, "Heart Disease Risk Stratification & Granular Clinical Severity Assessment (Cleveland Cohort)", 
        ha='center', va='center', color='#94A3B8', fontsize=11, fontstyle='italic', zorder=4)

# ==========================================
# 1. INPUT STAGE: UCI CLEVELAND DATASET
# ==========================================
draw_header_card(ax, 3, 44, 13, 45, "1. DATA SOURCE", "UCI Repository Benchmark", CLR_INPUT)
# Content inside Data Source
ax.text(9.5, 74.5, "UCI Cleveland Clinic\nHeart Disease Cohort", ha='center', va='center', 
        fontsize=9.5, fontweight='bold', color=CLR_INPUT['text'], zorder=4)
ax.text(9.5, 70.8, "N = 303 Patient Records\n14 Standard Clinical Features", ha='center', va='center', 
        fontsize=8.5, color='#475569', zorder=4)

features = [
    "Demographics: age, sex",
    "Symptoms: cp (chest pain)",
    "Hemodynamics: trestbps, thalach",
    "Metabolic: chol, fbs",
    "ECG: restecg, slope, oldpeak",
    "Pathology: ca, thal, exang",
    "Target: num (Severity 0 to 4)"
]
for i, feat in enumerate(features):
    draw_pill(ax, 3.8, 65.5 - (i * 3.3), 11.4, 2.5, feat, '#F0F9FF', '#BAE6FD', '#0369A1', fontsize=7.8)

# Target highlight
draw_pill(ax, 3.8, 45.0, 11.4, 3.0, "Clinical Target: Severity 0 - 4\n(No. of vessels >50% stenosis)", 
          '#FEF2F2', '#FECACA', '#991B1B', fontsize=7.5, bold=True)

# ==========================================
# 2. STAGE 2: DATA PREPROCESSING PIPELINE
# ==========================================
draw_header_card(ax, 19, 44, 13.5, 45, "2. PREPROCESSING", "Data Preparation Pipeline", CLR_PREP)

prep_steps = [
    ("Missing Value Handling", "Identification of missing\nattributes in 'ca' and 'thal'"),
    ("Outlier Detection & IQR", "Tukey's IQR clipping for\nhemodynamic anomalies"),
    ("Robust Z-Score Scaling", "Standardization for\ncontinuous parameters"),
    ("Fuzzy Domain Partitioning", "Continuous-to-fuzzy\nmembership definition"),
    ("Binary Transformation", "Hopfield discrete bipolar\nencoding {-1, +1} mapping"),
    ("Stratified K-Fold Split", "Patient-level 80/20 train/test\nstratified cross-validation")
]

for i, (title, desc) in enumerate(prep_steps):
    card_y = 73.0 - (i * 5.2)
    p_box = FancyBboxPatch((19.8, card_y), 11.9, 4.4, boxstyle="round,pad=0,rounding_size=0.6",
                           facecolor='#F8FAFC', edgecolor='#CBD5E1', linewidth=1.0, zorder=3)
    ax.add_patch(p_box)
    ax.text(25.75, card_y + 3.0, title, ha='center', va='center', fontsize=8.2, fontweight='bold', color='#1E293B', zorder=4)
    ax.text(25.75, card_y + 1.3, desc, ha='center', va='center', fontsize=7.0, color='#64748B', zorder=4)

draw_pill(ax, 19.8, 45.0, 11.9, 2.8, "Cleaned, Normalized &\nStructured Feature Matrices", '#F1F5F9', '#94A3B8', '#334155', fontsize=7.5, bold=True)

# Arrow from Input to Preprocessing
draw_arrow(ax, (16.0, 66.5), (19.0, 66.5), "Raw Data", color='#0284C7', lw=2.2)

# ==============================================================================
# 3. FOUR COMPUTATIONAL INTELLIGENCE MODULES (THE CORE ENGINE)
# ==============================================================================
# Outer Container Box for CI Modules
ci_bg = FancyBboxPatch((35.5, 20), 41.5, 69, boxstyle="round,pad=0,rounding_size=1.5",
                       facecolor='#F8FAFC', edgecolor='#94A3B8', linewidth=1.8, linestyle='--', zorder=1)
ax.add_patch(ci_bg)
ax.text(56.25, 87.2, "3. HYBRID COMPUTATIONAL INTELLIGENCE ENGINE (4 DIVERSE PARADIGMS)", 
        ha='center', va='center', color='#1E293B', fontsize=12.5, fontweight='bold', zorder=2)

# Connector line from Preprocessing to CI Container
draw_arrow(ax, (32.5, 66.5), (35.5, 66.5), "Clinical Tensors", color='#475569', lw=2.4)

# -------------------------------------------------------------
# MODULE A: GENETIC ALGORITHM (GA) - Feature & Topology Selection
# -------------------------------------------------------------
draw_header_card(ax, 37, 56.5, 18, 28, "MODULE A: GENETIC ALGORITHM", "Feature Selection & Parameter Tuning", CLR_GA)
ga_items = [
    ("Chromosome Encoding", "Binary 13-bit clinical vector\n[1=Retain, 0=Mask attribute]"),
    ("Fitness Function", "Maximize F1 & Multi-Class AUC\nPenalty for feature cardinality"),
    ("Evolutionary Search", "Tournament Selection (k=3)\nUniform Crossover & Bit Mutation"),
    ("Optimization Goal", "Eliminates redundant biomarkers\nSolves gradient local minima trap")
]
for i, (g_title, g_desc) in enumerate(ga_items):
    gy = 73.0 - (i * 4.4)
    g_box = FancyBboxPatch((37.8, gy), 16.4, 3.8, boxstyle="round,pad=0,rounding_size=0.5",
                           facecolor=CLR_GA['sub'], edgecolor='#C7D2FE', linewidth=0.9, zorder=3)
    ax.add_patch(g_box)
    ax.text(46.0, gy + 2.6, g_title, ha='center', va='center', fontsize=8.0, fontweight='bold', color=CLR_GA['text'], zorder=4)
    ax.text(46.0, gy + 1.1, g_desc, ha='center', va='center', fontsize=6.8, color='#4338CA', zorder=4)

draw_pill(ax, 37.8, 57.5, 16.4, 2.2, "Optimal Diagnostic Feature Subsets", '#EEF2FF', '#818CF8', '#312E81', fontsize=7.5, bold=True)

# -------------------------------------------------------------
# MODULE B: HOPFIELD NEURAL NETWORK (HNN) - Associative Memory
# -------------------------------------------------------------
draw_header_card(ax, 57.5, 56.5, 18, 28, "MODULE B: HOPFIELD NETWORK", "Associative Recall & Noise Cleanup", CLR_HOPFIELD)
hnn_items = [
    ("Recurrent Memory", "Fully interconnected symmetric\nassociative neural matrix"),
    ("Lyapunov Energy Function", "E = -1/2 \u2211\u2211 Wij Si Sj\nMonotonic energy descent"),
    ("Attractor Storage", "Stores prototypical clinical vectors\n[Healthy, Mild, Moderate, Severe]"),
    ("Incomplete Profile Recall", "Dynamic convergence recovers missing\nor noisy patient lab biomarkers")
]
for i, (h_title, h_desc) in enumerate(hnn_items):
    hy = 73.0 - (i * 4.4)
    h_box = FancyBboxPatch((58.3, hy), 16.4, 3.8, boxstyle="round,pad=0,rounding_size=0.5",
                           facecolor=CLR_HOPFIELD['sub'], edgecolor='#99F6E4', linewidth=0.9, zorder=3)
    ax.add_patch(h_box)
    ax.text(66.5, hy + 2.6, h_title, ha='center', va='center', fontsize=8.0, fontweight='bold', color=CLR_HOPFIELD['text'], zorder=4)
    ax.text(66.5, hy + 1.1, h_desc, ha='center', va='center', fontsize=6.8, color='#0F766E', zorder=4)

draw_pill(ax, 58.3, 57.5, 16.4, 2.2, "Restored & De-noised Patient Profiles", '#F0FDFA', '#2DD4BF', '#134E4A', fontsize=7.5, bold=True)

# -------------------------------------------------------------
# MODULE C: FUZZY LOGIC SYSTEM (FL) - Uncertainty & Risk
# -------------------------------------------------------------
draw_header_card(ax, 37, 23, 18, 30.5, "MODULE C: FUZZY LOGIC SYSTEM", "Uncertainty Modeling & Risk Estimation", CLR_FUZZY)
fl_items = [
    ("Fuzzification Interface", "Triangular/Gaussian membership \u03bc(x)\n[e.g., SBP: Normotensive/Border/High]"),
    ("Clinical Knowledge Base", "Expert heuristic IF-THEN rules\nFormulated with cardiologists"),
    ("Mamdani Inference Engine", "Min-Max composition evaluates\nmultivariate clinical gray zones"),
    ("Centroid Defuzzification", "Transforms fuzzy risk surface into\ncontinuous risk score [0 - 100%]")
]
for i, (f_title, f_desc) in enumerate(fl_items):
    fy = 42.0 - (i * 4.4)
    f_box = FancyBboxPatch((37.8, fy), 16.4, 3.8, boxstyle="round,pad=0,rounding_size=0.5",
                           facecolor=CLR_FUZZY['sub'], edgecolor='#FDE68A', linewidth=0.9, zorder=3)
    ax.add_patch(f_box)
    ax.text(46.0, fy + 2.6, f_title, ha='center', va='center', fontsize=8.0, fontweight='bold', color=CLR_FUZZY['text'], zorder=4)
    ax.text(46.0, fy + 1.1, f_desc, ha='center', va='center', fontsize=6.8, color='#92400E', zorder=4)

draw_pill(ax, 37.8, 24.2, 16.4, 2.4, "Continuous Fuzzy Risk & Uncertainty Index", '#FFFBEB', '#F59E0B', '#78350F', fontsize=7.5, bold=True)

# -------------------------------------------------------------
# MODULE D: MULTILAYER PERCEPTRON (MLP) - Severity Staging
# -------------------------------------------------------------
draw_header_card(ax, 57.5, 23, 18, 30.5, "MODULE D: MULTILAYER PERCEPTRON", "Non-Linear Deep Severity Staging", CLR_MLP)
mlp_items = [
    ("Dense Architecture", "Input layer + 3 Hidden Layers\n(128, 64, 32 nodes) with Leaky ReLU"),
    ("Regularization & Norm", "Dropout (p=0.3) + Batch Normalization\nL2 weight decay to prevent overfitting"),
    ("Optimization & Loss", "Adam Optimizer + Cross-Entropy Loss\nDynamic learning rate scheduler"),
    ("Softmax Staging Layer", "5-Node probability distribution\nOutputs: Clinical Stages 0, 1, 2, 3, 4")
]
for i, (m_title, m_desc) in enumerate(mlp_items):
    my = 42.0 - (i * 4.4)
    m_box = FancyBboxPatch((58.3, my), 16.4, 3.8, boxstyle="round,pad=0,rounding_size=0.5",
                           facecolor=CLR_MLP['sub'], edgecolor='#BFDBFE', linewidth=0.9, zorder=3)
    ax.add_patch(m_box)
    ax.text(66.5, my + 2.6, m_title, ha='center', va='center', fontsize=8.0, fontweight='bold', color=CLR_MLP['text'], zorder=4)
    ax.text(66.5, my + 1.1, m_desc, ha='center', va='center', fontsize=6.8, color='#1E40AF', zorder=4)

draw_pill(ax, 58.3, 24.2, 16.4, 2.4, "Multi-Class Categorical Likelihoods", '#EFF6FF', '#3B82F6', '#1E3A8A', fontsize=7.5, bold=True)

# Internal CI Inter-Module Arrows (Crucial Hybrid Links!)
# 1. GA to MLP (Selected features)
draw_arrow(ax, (46, 56.5), (62, 53.5), "Feature Mask", color='#4F46E5', rad=0.2, lw=1.8)
# 2. Hopfield to MLP (Cleaned/reconstructed vectors)
draw_arrow(ax, (66.5, 56.5), (66.5, 53.5), "Recalled Tensors", color='#0D9488', rad=0.0, lw=1.8)
# 3. GA to Fuzzy (Optimized Membership Bounds)
draw_arrow(ax, (42, 56.5), (42, 53.5), "Tuned Variables", color='#4F46E5', rad=0.0, lw=1.6)

# ==========================================
# 4. STAGE 4: INTEGRATED OUTPUT ENGINE
# ==========================================
draw_header_card(ax, 79.5, 53, 17.5, 36, "4. INTEGRATED DECISION", "Neuro-Fuzzy Associative Fusion", CLR_FUSION)

ax.text(88.25, 84.5, "Multi-Paradigm Hybrid Fusion Layer", ha='center', va='center', 
        fontsize=8.8, fontweight='bold', color=CLR_FUSION['text'], zorder=4)
ax.text(88.25, 82.0, "Joint Probability & Fuzzy Decision Rule\nSeverity Categorization + Uncertainty Index", 
        ha='center', va='center', fontsize=7.3, color='#64748B', zorder=4)

out_boxes = [
    ("Stage 0: No Significant Disease", "0 major vessels narrowed (<50%)\nTherapy: Primary Prevention / Lifestyle", '#F0FDF4', '#86EFAC', '#166534'),
    ("Stage 1: Mild Single-Vessel CAD", "1 major coronary vessel stenosis\nTherapy: Aggressive Statin / Antiplatelet", '#EFF6FF', '#93C5FD', '#1E40AF'),
    ("Stage 2: Moderate Double-Vessel", "2 epicardial coronary vessels\nTherapy: Dual Therapy & Stress Testing", '#FEFCE8', '#FDE047', '#854D0E'),
    ("Stage 3: Severe Triple-Vessel CAD", "3 major coronary vessels compromised\nTherapy: Coronary Angiography & PCI", '#FFF7ED', '#FDBA74', '#9A3412'),
    ("Stage 4: Critical Multi-Vessel CAD", "Severe multi-vessel / Left-Main equiv.\nTherapy: Urgent Surgical CABG Triage", '#FEF2F2', '#FCA5A5', '#991B1B')
]

for i, (o_title, o_desc, bg_c, bd_c, tx_c) in enumerate(out_boxes):
    oy = 74.5 - (i * 4.1)
    ob = FancyBboxPatch((80.3, oy), 15.9, 3.6, boxstyle="round,pad=0,rounding_size=0.5",
                        facecolor=bg_c, edgecolor=bd_c, linewidth=1.0, zorder=3)
    ax.add_patch(ob)
    ax.text(88.25, oy + 2.5, o_title, ha='center', va='center', fontsize=7.6, fontweight='bold', color=tx_c, zorder=4)
    ax.text(88.25, oy + 1.1, o_desc, ha='center', va='center', fontsize=6.4, color=tx_c, zorder=4)

draw_pill(ax, 80.3, 54.0, 15.9, 2.8, "Dual Output: Multi-Class Severity Staging\n+ Explainable Fuzzy Risk Certainty", 
          '#FFF1F2', '#F43F5E', '#9F1239', fontsize=7.2, bold=True)

# Arrows from Modules to Fusion
draw_arrow(ax, (75.5, 38.0), (79.5, 62.0), "MLP Staging Logits", color='#1E40AF', rad=0.15, lw=2.2)
draw_arrow(ax, (55.0, 30.0), (79.5, 57.0), "Fuzzy Risk Surface", color='#B45309', rad=-0.15, lw=2.0)

# ==========================================
# 5. STAGE 5: PERFORMANCE EVALUATION
# ==========================================
draw_header_card(ax, 79.5, 12, 17.5, 38, "5. PERFORMANCE EVALUATION", "Clinical & Statistical Validation", CLR_EVAL)

eval_metrics = [
    ("Diagnostic Discrimination", "Multi-Class Accuracy, Macro Precision,\nRecall (Sensitivity), Specificity, Macro F1"),
    ("ROC-AUC & Precision-Recall", "One-vs-Rest (OvR) Multi-Class ROC Curves\nMicro/Macro Area Under the PR Curve"),
    ("Clinical Confusion Matrix", "Vessel-Level Error Mapping (0 vs 1-4)\nQuantifies critical under-staging errors"),
    ("Optimization Convergence", "Lyapunov energy descent monitoring (HNN)\nFitness trajectory over 100 generations (GA)"),
    ("Cross-Cohort Generalization", "10-Fold Stratified Cross-Validation\nOut-of-sample robustness testing")
]

for i, (e_title, e_desc) in enumerate(eval_metrics):
    ey = 42.5 - (i * 4.7)
    eb = FancyBboxPatch((80.3, ey), 15.9, 4.0, boxstyle="round,pad=0,rounding_size=0.5",
                        facecolor=CLR_EVAL['sub'], edgecolor='#A7F3D0', linewidth=0.9, zorder=3)
    ax.add_patch(eb)
    ax.text(88.25, ey + 2.8, e_title, ha='center', va='center', fontsize=8.0, fontweight='bold', color=CLR_EVAL['text'], zorder=4)
    ax.text(88.25, ey + 1.2, e_desc, ha='center', va='center', fontsize=6.8, color='#047857', zorder=4)

draw_pill(ax, 80.3, 13.5, 15.9, 3.2, "Clinical Decision Support System (CDSS)\nValidated for Early Triage & Intervention", 
          '#ECFDF5', '#10B981', '#064E3B', fontsize=7.5, bold=True)

# Arrow from Decision Output down to Performance Evaluation
draw_arrow(ax, (88.25, 53.0), (88.25, 50.0), "Validation Pipeline", color='#047857', lw=2.2)

# ==========================================
# LEGEND & CITATION FOOTER
# ==========================================
footer_bg = FancyBboxPatch((2, 2.5), 96, 7.5, boxstyle="round,pad=0,rounding_size=0.8",
                           facecolor='#FFFFFF', edgecolor='#CBD5E1', linewidth=1.2, zorder=2)
ax.add_patch(footer_bg)

# Legend elements
ax.text(4, 7.2, "SYSTEM ARCHITECTURE LEGEND & WORKFLOW SUMMARY:", fontsize=8.8, fontweight='bold', color='#0F172A', zorder=4)
legend_items = [
    ("UCI Cleveland Dataset", CLR_INPUT['header']),
    ("Data Preprocessing", CLR_PREP['header']),
    ("Genetic Algorithm (GA)", CLR_GA['header']),
    ("Hopfield Network (HNN)", CLR_HOPFIELD['header']),
    ("Fuzzy Logic (FL)", CLR_FUZZY['header']),
    ("Multilayer Perceptron (MLP)", CLR_MLP['header']),
    ("Integrated Fusion", CLR_FUSION['header']),
    ("Clinical Evaluation", CLR_EVAL['header'])
]

for idx, (leg_name, leg_col) in enumerate(legend_items):
    lx = 4.0 + (idx % 4) * 23.5
    ly = 5.2 if idx < 4 else 3.6
    bullet = patches.Circle((lx + 0.8, ly), 0.5, facecolor=leg_col, edgecolor='none', zorder=5)
    ax.add_patch(bullet)
    ax.text(lx + 2.0, ly, leg_name, ha='left', va='center', fontsize=8.0, color='#334155', fontweight='medium', zorder=5)

plt.tight_layout()
output_path = os.path.join(os.getcwd(), 'Heart_Disease_System_Architecture.png')
plt.savefig(output_path, dpi=300, bbox_inches='tight', facecolor='#F8FAFC')
plt.close()

print(f"Diagram successfully generated at: {output_path}")
