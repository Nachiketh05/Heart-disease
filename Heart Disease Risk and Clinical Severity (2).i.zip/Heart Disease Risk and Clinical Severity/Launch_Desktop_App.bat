@echo off
title Heart Disease Clinical Decision Support Desktop App
cd /d "%~dp0"
echo =================================================================
echo   STARTING HEART DISEASE CLINICAL DECISION SUPPORT APP...
echo =================================================================
python heart_disease_desktop_app.py
pause
