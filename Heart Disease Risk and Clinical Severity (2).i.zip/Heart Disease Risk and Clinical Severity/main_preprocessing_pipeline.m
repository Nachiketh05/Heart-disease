% =========================================================================
% MASTER PREPROCESSING PIPELINE FOR UCI CLEVELAND HEART DISEASE DATASET
% =========================================================================
% Academic Project: Heart Disease Risk & Clinical Severity Assessment
% Framework: Multilayer Perceptron, Hopfield Network, Fuzzy Logic, Genetic Algo
%
% This script executes the complete, leak-free preprocessing pipeline:
%   1. Data Loading & Verification (303 records, 14 attributes)
%   2. Clinical Attribute Classification & Missing Value Auditing
%   3. Stratified Train / Validation / Test Partitioning (70% / 15% / 15%)
%   4. Anti-Leakage Parameter Fitting (Fitted strictly on Training partition)
%   5. Feature Encoding (One-Hot for Nominal, Ordinal preservation, Scaling)
%   6. Transformation of Train, Val, and Test splits
%   7. Class Distribution Analysis & Artifact Saving (cleveland_preprocessed.mat)
% =========================================================================

clear; clc; close all;

fprintf('=================================================================\n');
fprintf('   UCI CLEVELAND HEART DISEASE DATASET PREPROCESSING PIPELINE   \n');
fprintf('=================================================================\n\n');

%% 1. LOAD DATASET
dataFile = 'processed.cleveland.data';
rawTable = loadClevelandData(dataFile);

[nTotal, nCols] = size(rawTable);
fprintf('Total Records Loaded:    %d\n', nTotal);
fprintf('Total Columns:           %d (13 Clinical Attributes + 1 Target)\n\n', nCols);

%% 2. ATTRIBUTE AUDIT & MISSING VALUE ANALYSIS
fprintf('-----------------------------------------------------------------\n');
fprintf('CLINICAL ATTRIBUTE AUDITING & MISSING VALUE REPORT\n');
fprintf('-----------------------------------------------------------------\n');

attrInfo = {
    'age',      'Age in years',                                  'Continuous Numerical',   sum(isnan(rawTable.age));
    'sex',      'Biological sex (1=Male, 0=Female)',             'Binary Nominal',         sum(isnan(rawTable.sex));
    'cp',       'Chest pain type (1=Typ, 2=Atyp, 3=Non, 4=Asym)','Multi-Class Nominal',   sum(isnan(rawTable.cp));
    'trestbps', 'Resting blood pressure (mm Hg on admission)',   'Continuous Numerical',   sum(isnan(rawTable.trestbps));
    'chol',     'Serum cholesterol (mg/dl)',                     'Continuous Numerical',   sum(isnan(rawTable.chol));
    'fbs',      'Fasting blood sugar > 120 mg/dl (1=True, 0=F)', 'Binary Nominal',         sum(isnan(rawTable.fbs));
    'restecg',  'Resting ECG (0=Normal, 1=ST-T, 2=LVH)',         'Multi-Class Nominal',   sum(isnan(rawTable.restecg));
    'thalach',  'Max heart rate achieved during exercise',       'Continuous Numerical',   sum(isnan(rawTable.thalach));
    'exang',    'Exercise induced angina (1=Yes, 0=No)',         'Binary Nominal',         sum(isnan(rawTable.exang));
    'oldpeak',  'ST depression induced by exercise (mm)',        'Continuous Numerical',   sum(isnan(rawTable.oldpeak));
    'slope',    'Peak exercise ST slope (1=Up, 2=Flat, 3=Down)', 'Ordinal Categorical',    sum(isnan(rawTable.slope));
    'ca',       'Major vessels (0-3) colored by fluoroscopy',    'Discrete / Ordinal',     sum(isnan(rawTable.ca));
    'thal',     'Thallium scan (3=Normal, 6=Fixed, 7=Revers)',   'Multi-Class Nominal',   sum(isnan(rawTable.thal));
    'num',      'Target: Severity Stage (0, 1, 2, 3, 4)',        'Multi-Class Target',     sum(isnan(rawTable.num));
};

fprintf('%-10s | %-45s | %-22s | %s\n', 'Name', 'Description', 'Clinical Category', 'Missing Count');
fprintf('----------------------------------------------------------------------------------------------------\n');
for i = 1:size(attrInfo, 1)
    fprintf('%-10s | %-45s | %-22s | %d\n', attrInfo{i, 1}, attrInfo{i, 2}, attrInfo{i, 3}, attrInfo{i, 4});
end
fprintf('\nTotal Missing Values in Dataset: %d (ca: 4, thal: 2 across 6 distinct patient rows)\n\n', ...
        sum(isnan(rawTable.ca)) + sum(isnan(rawTable.thal)));

%% 3. TARGET CLASS DISTRIBUTION ANALYSIS
fprintf('-----------------------------------------------------------------\n');
fprintf('TARGET VARIABLE (num) MULTI-CLASS DISTRIBUTION\n');
fprintf('-----------------------------------------------------------------\n');
classCounts = histcounts(rawTable.num, -0.5:1:4.5);
stageDesc = {
    'Stage 0: Normal / Absence of significant disease (<50% diameter stenosis)';
    'Stage 1: Single-vessel coronary artery disease';
    'Stage 2: Double-vessel coronary artery disease';
    'Stage 3: Triple-vessel coronary artery disease';
    'Stage 4: Critical multi-vessel CAD / Left-Main equivalent'
};

for c = 0:4
    fprintf('  Category %d: %3d records (%5.2f%%) - %s\n', ...
            c, classCounts(c+1), 100*classCounts(c+1)/nTotal, stageDesc{c+1});
end
fprintf('  Binary Summary: Absence (0)=%d (%.1f%%) | Presence (1-4)=%d (%.1f%%)\n\n', ...
        classCounts(1), 100*classCounts(1)/nTotal, sum(classCounts(2:5)), 100*sum(classCounts(2:5))/nTotal);

%% 4. STRATIFIED DATA PARTITIONING (70% Train, 15% Validation, 15% Test)
fprintf('-----------------------------------------------------------------\n');
fprintf('STRATIFIED DATA PARTITIONING (ANTI-LEAKAGE SPLIT)\n');
fprintf('-----------------------------------------------------------------\n');
seed = 42;
[trainIdx, valIdx, testIdx] = stratifiedSplit(rawTable.num, 0.70, 0.15, 0.15, seed);

trainTable = rawTable(trainIdx, :);
valTable   = rawTable(valIdx, :);
testTable  = rawTable(testIdx, :);

% Display split distribution matrix
fprintf('\nClass Proportions Across Partitions:\n');
fprintf('%-10s | %-12s | %-12s | %-12s | %s\n', 'Category', 'Train Count (%)', 'Val Count (%)', 'Test Count (%)', 'Total');
fprintf('-------------------------------------------------------------------------------\n');
for c = 0:4
    trC = sum(trainTable.num == c);
    vaC = sum(valTable.num == c);
    teC = sum(testTable.num == c);
    fprintf('Class %d   | %3d (%5.1f%%)   | %3d (%5.1f%%)   | %3d (%5.1f%%)   | %3d\n', ...
            c, trC, 100*trC/height(trainTable), vaC, 100*vaC/height(valTable), teC, 100*teC/height(testTable), classCounts(c+1));
end
fprintf('TOTAL      | %3d (100.0%%)  | %3d (100.0%%)  | %3d (100.0%%)  | %3d\n\n', ...
        height(trainTable), height(valTable), height(testTable), nTotal);

%% 5. FIT PREPROCESSING STRICTLY ON TRAINING DATA
fprintf('-----------------------------------------------------------------\n');
fprintf('FITTING PREPROCESSING PARAMETERS (TRAINING PARTITION ONLY)\n');
fprintf('-----------------------------------------------------------------\n');
normMethod = 'zscore'; % Options: 'zscore' or 'minmax'
prepModel = fitPreprocessing(trainTable, normMethod);

%% 6. APPLY TRANSFORMATION TO TRAIN, VALIDATION, AND TEST SETS
fprintf('\n-----------------------------------------------------------------\n');
fprintf('APPLYING FROZEN PREPROCESSING TO ALL PARTITIONS\n');
fprintf('-----------------------------------------------------------------\n');
useOneHot = true; % One-Hot encoding for nominal categorical attributes

[X_train, y_train, featNames, trainTableClean] = applyPreprocessing(trainTable, prepModel, useOneHot);
[X_val,   y_val,   ~,         valTableClean]   = applyPreprocessing(valTable,   prepModel, useOneHot);
[X_test,  y_test,  ~,         testTableClean]  = applyPreprocessing(testTable,  prepModel, useOneHot);

fprintf('Feature Matrix Dimensions:\n');
fprintf('  X_train: [%d x %d],  y_train: [%d x 1]\n', size(X_train, 1), size(X_train, 2), numel(y_train));
fprintf('  X_val:   [%d x %d],  y_val:   [%d x 1]\n', size(X_val, 1), size(X_val, 2), numel(y_val));
fprintf('  X_test:  [%d x %d],  y_test:  [%d x 1]\n', size(X_test, 1), size(X_test, 2), numel(y_test));
fprintf('Total Features in Engineered Matrix: %d\n\n', numel(featNames));

fprintf('Encoded Feature Names:\n');
for i = 1:numel(featNames)
    fprintf('  Col %2d: %s\n', i, featNames{i});
end
fprintf('\n');

%% 7. SAVE PROCESSED MATRICES FOR DOWNSTREAM CI MODULES
outputMatFile = 'cleveland_preprocessed.mat';
save(outputMatFile, ...
     'X_train', 'y_train', ...
     'X_val',   'y_val', ...
     'X_test',  'y_test', ...
     'featNames', 'prepModel', ...
     'trainTableClean', 'valTableClean', 'testTableClean', ...
     'trainIdx', 'valIdx', 'testIdx');

fprintf('=================================================================\n');
fprintf('[SUCCESS] Preprocessed tensors saved to "%s"\n', outputMatFile);
fprintf('Ready for: MLP, Hopfield Network, Fuzzy Logic, and Genetic Algorithm.\n');
fprintf('=================================================================\n');
