@echo off
title Heart Disease Risk & Clinical Severity Assessment - MATLAB Application Launcher
cd /d "%~dp0"
echo =================================================================
echo   LAUNCHING MATLAB HEART DISEASE CLINICAL DECISION SUPPORT APP   
echo =================================================================
echo Starting MATLAB and executing run_app.m...

if exist "C:\Program Files\Polyspace\R2021a\bin\matlab.exe" (
    "C:\Program Files\Polyspace\R2021a\bin\matlab.exe" -nodesktop -nosplash -r "run_app"
) else (
    matlab -nodesktop -nosplash -r "run_app"
)
pause
