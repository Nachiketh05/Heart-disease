function rawTable = loadClevelandData(filename)
% LOADCLEVELANDDATA Loads the UCI Cleveland Heart Disease dataset.
%
%   rawTable = loadClevelandData(filename)
%
%   Input:
%       filename - Path to 'processed.cleveland.data' (CSV text format)
%
%   Output:
%       rawTable - MATLAB table containing 303 records and 14 clinical attributes:
%                  age, sex, cp, trestbps, chol, fbs, restecg, thalach,
%                  exang, oldpeak, slope, ca, thal, num
%
%   Description:
%       The raw dataset represents missing values with the character '?'.
%       This function reads the file, replaces '?' with NaN, casts columns
%       to appropriate double precision numeric types, and verifies dataset integrity.

    if nargin < 1 || isempty(filename)
        filename = 'processed.cleveland.data';
    end

    if ~isfile(filename)
        error('File "%s" not found. Please ensure processed.cleveland.data exists in the directory.', filename);
    end

    % Define canonical clinical attribute names according to UCI specification
    colNames = {'age', 'sex', 'cp', 'trestbps', 'chol', 'fbs', ...
                'restecg', 'thalach', 'exang', 'oldpeak', 'slope', ...
                'ca', 'thal', 'num'};

    % Configure text reading options to handle '?' as missing (NaN)
    opts = detectImportOptions(filename, 'FileType', 'delimitedtext');
    opts.Delimiter = ',';
    opts.VariableNames = colNames;
    opts.MissingRule = 'fill';
    
    % Ensure all 14 columns are parsed as numeric doubles
    for i = 1:numel(colNames)
        opts = setvartype(opts, colNames{i}, 'double');
    end

    % Read table
    rawTable = readtable(filename, opts);

    % Verification checks
    [nRows, nCols] = size(rawTable);
    if nRows ~= 303 || nCols ~= 14
        warning('Expected 303 rows and 14 columns, but loaded %d rows and %d columns.', nRows, nCols);
    else
        fprintf('[LOAD] Successfully loaded UCI Cleveland dataset: %d patient records, %d attributes.\n', nRows, nCols);
    end
end
