function hybridResults = hybridModelSuite(X_train, y_train, X_val, y_val, X_test, y_test, prepModel, rawTrain, rawVal, rawTest, gaResult)
% HYBRIDMODELSUITE Executes and benchmarks the hybrid computational intelligence architectures:
%   1. Baseline MLP (All 20 Preprocessed Features / 13 Clinical Attributes)
%   2. Hybrid 1: Fuzzy Logic + MLP (Fuzzy Feature Augmentation)
%   3. Hybrid 2: Genetic Algorithm + MLP (Evolutionary Feature Selection)
%
%   Usage:
%       hybridResults = hybridModelSuite(X_train, y_train, X_val, y_val, X_test, y_test, ...
%                                        prepModel, rawTrain, rawVal, rawTest, gaResult)
%
%   Mathematical Formulations:
%       - Hybrid 1: X_fuzzy_aug = [X, z*/100, mu_trestbps(3), mu_chol(3), mu_thalach(3), mu_oldpeak(3)]
%         Augments standard statistical features with epistemic fuzzy uncertainty vectors.
%       - Hybrid 2: X_ga = X(:, cols(bestChromosome_13))
%         Reduces dimension and eliminates noisy/redundant biomarkers.
%       - Rigorous Zero-Leakage: All MLPs trained on Train fold, tuned on Val fold, evaluated on Test fold.

    fprintf('=================================================================\n');
    fprintf('  HYBRID COMPUTATIONAL INTELLIGENCE SUITE BENCHMARKING           \n');
    fprintf('=================================================================\n\n');

    mlpOpts = struct();
    mlpOpts.hiddenDims = [64, 32];
    mlpOpts.epochs = 250;
    mlpOpts.learningRate = 0.005;
    mlpOpts.l2Lambda = 0.001;
    mlpOpts.batchSize = 32;
    mlpOpts.verbose = false;

    %% --------------------------------------------------------------------
    % 1. BASELINE MODEL: ALL-FEATURE MLP
    %% --------------------------------------------------------------------
    fprintf('[MODEL 1] Training Baseline All-Feature MLP (Input Dim = %d)...\n', size(X_train, 2));
    rng(42);
    baseMlpModel = mlpClassifier('train', X_train, y_train, X_val, y_val, mlpOpts);
    baseMetrics = mlpClassifier('evaluate', baseMlpModel, X_test, y_test);
    fprintf('          Baseline Test Acc: %.2f%% | Macro-F1: %.4f\n\n', ...
            100 * baseMetrics.accuracy, baseMetrics.macroF1);

    %% --------------------------------------------------------------------
    % 2. HYBRID 1: FUZZY LOGIC + MLP (Fuzzy Feature Augmentation)
    %% --------------------------------------------------------------------
    fprintf('[MODEL 2] Engineering Hybrid 1: Fuzzy Logic + MLP Feature Augmentation...\n');
    fis = fuzzyLogicSystem('build');

    % Extract unscaled continuous variables for Mamdani FIS [trestbps, chol, thalach, oldpeak]
    trainFzInputs = extractFuzzyInputs(rawTrain);
    valFzInputs   = extractFuzzyInputs(rawVal);
    testFzInputs  = extractFuzzyInputs(rawTest);

    % Compute continuous risk scores and membership degree tensors
    [trainFzScore, ~, trainFzDet] = fuzzyLogicSystem('evaluate', fis, trainFzInputs);
    [valFzScore,   ~, valFzDet]   = fuzzyLogicSystem('evaluate', fis, valFzInputs);
    [testFzScore,  ~, testFzDet]  = fuzzyLogicSystem('evaluate', fis, testFzInputs);

    % Construct augmented feature matrices
    X_train_fz = assembleFuzzyAugmentedMatrix(X_train, trainFzScore, trainFzDet);
    X_val_fz   = assembleFuzzyAugmentedMatrix(X_val,   valFzScore,   valFzDet);
    X_test_fz  = assembleFuzzyAugmentedMatrix(X_test,  testFzScore,  testFzDet);

    fprintf('          Augmented Feature Space: %d -> %d features (added risk score + 12 MF degrees)\n', ...
            size(X_train, 2), size(X_train_fz, 2));

    rng(42);
    hybrid1MlpModel = mlpClassifier('train', X_train_fz, y_train, X_val_fz, y_val, mlpOpts);
    hybrid1Metrics  = mlpClassifier('evaluate', hybrid1MlpModel, X_test_fz, y_test);
    fprintf('          Hybrid 1 Test Acc: %.2f%% | Macro-F1: %.4f\n\n', ...
            100 * hybrid1Metrics.accuracy, hybrid1Metrics.macroF1);

    %% --------------------------------------------------------------------
    % 3. HYBRID 2: GENETIC ALGORITHM + MLP (Evolutionary Feature Selection)
    %% --------------------------------------------------------------------
    fprintf('[MODEL 3] Engineering Hybrid 2: GA + MLP Feature Selection...\n');
    if nargin < 11 || isempty(gaResult)
        gaOpts = struct('popSize', 30, 'generations', 35, 'verbose', false);
        gaResult = geneticAlgorithm(X_train, y_train, X_val, y_val, gaOpts);
    end

    gaCols = gaResult.selectedEncodedColumns;
    X_train_ga = X_train(:, gaCols);
    X_val_ga   = X_val(:, gaCols);
    X_test_ga  = X_test(:, gaCols);

    fprintf('          Optimized Feature Space: %d columns (from %d selected clinical attributes)\n', ...
            numel(gaCols), gaResult.numSelectedFeatures);

    rng(42);
    hybrid2MlpModel = mlpClassifier('train', X_train_ga, y_train, X_val_ga, y_val, mlpOpts);
    hybrid2Metrics  = mlpClassifier('evaluate', hybrid2MlpModel, X_test_ga, y_test);
    fprintf('          Hybrid 2 Test Acc: %.2f%% | Macro-F1: %.4f\n\n', ...
            100 * hybrid2Metrics.accuracy, hybrid2Metrics.macroF1);

    %% --------------------------------------------------------------------
    % 4. COMPARATIVE SYNTHESIS
    %% --------------------------------------------------------------------
    fprintf('-----------------------------------------------------------------\n');
    fprintf('COMPARATIVE MODEL PERFORMANCE SUMMARY (TEST COHORT, N=%d):\n', numel(y_test));
    fprintf('-----------------------------------------------------------------\n');
    fprintf('%-24s | %-8s | %-10s | %-10s | %-10s\n', ...
            'Architecture', 'Features', 'Accuracy', 'Macro-Prec', 'Macro-F1');
    fprintf('-----------------------------------------------------------------\n');
    fprintf('%-24s | %-8d | %-9.2f%% | %-10.4f | %-10.4f\n', ...
            'Baseline MLP (All Feats)', size(X_train, 2), ...
            100 * baseMetrics.accuracy, baseMetrics.macroPrecision, baseMetrics.macroF1);
    fprintf('%-24s | %-8d | %-9.2f%% | %-10.4f | %-10.4f\n', ...
            'Hybrid 1 (Fuzzy + MLP)', size(X_train_fz, 2), ...
            100 * hybrid1Metrics.accuracy, hybrid1Metrics.macroPrecision, hybrid1Metrics.macroF1);
    fprintf('%-24s | %-8d | %-9.2f%% | %-10.4f | %-10.4f\n', ...
            'Hybrid 2 (GA + MLP)', numel(gaCols), ...
            100 * hybrid2Metrics.accuracy, hybrid2Metrics.macroPrecision, hybrid2Metrics.macroF1);
    fprintf('-----------------------------------------------------------------\n\n');

    % Return structured benchmark object
    hybridResults = struct();
    hybridResults.baseline = struct('model', baseMlpModel, 'metrics', baseMetrics, 'numFeatures', size(X_train, 2));
    hybridResults.hybrid1  = struct('model', hybrid1MlpModel, 'metrics', hybrid1Metrics, 'numFeatures', size(X_train_fz, 2), ...
                                   'X_test_fz', X_test_fz);
    hybridResults.hybrid2  = struct('model', hybrid2MlpModel, 'metrics', hybrid2Metrics, 'numFeatures', numel(gaCols), ...
                                   'gaResult', gaResult, 'X_test_ga', X_test_ga);
    hybridResults.comparisonTable = table( ...
        {'Baseline MLP'; 'Hybrid 1 (Fuzzy+MLP)'; 'Hybrid 2 (GA+MLP)'}, ...
        [size(X_train, 2); size(X_train_fz, 2); numel(gaCols)], ...
        [baseMetrics.accuracy; hybrid1Metrics.accuracy; hybrid2Metrics.accuracy] * 100, ...
        [baseMetrics.macroPrecision; hybrid1Metrics.macroPrecision; hybrid2Metrics.macroPrecision], ...
        [baseMetrics.macroRecall; hybrid1Metrics.macroRecall; hybrid2Metrics.macroRecall], ...
        [baseMetrics.macroF1; hybrid1Metrics.macroF1; hybrid2Metrics.macroF1], ...
        'VariableNames', {'Model', 'NumFeatures', 'Accuracy_Pct', 'Macro_Precision', 'Macro_Recall', 'Macro_F1'});
end

%% Helper: Extract 4 Continuous Features for Mamdani FIS
function fzInputs = extractFuzzyInputs(rawTable)
    if istable(rawTable)
        fzInputs = [rawTable.trestbps, rawTable.chol, rawTable.thalach, rawTable.oldpeak];
    else
        % Fallback array
        fzInputs = rawTable;
    end
end

%% Helper: Assemble Fuzzy-Augmented Matrix [X, riskScore/100, mu_degrees]
function X_aug = assembleFuzzyAugmentedMatrix(X_base, fzScores, fzDetails)
    N = size(X_base, 1);
    mfMatrix = zeros(N, 12);

    for i = 1:N
        mem = fzDetails.allMemberships{i};
        % 3 terms each for trestbps, chol, thalach, oldpeak
        mfMatrix(i, :) = [mem.trestbps, mem.chol, mem.thalach, mem.oldpeak];
    end

    % Concatenate: Base features + scaled risk score [0, 1] + 12 membership degrees
    X_aug = [X_base, fzScores / 100.0, mfMatrix];
end
