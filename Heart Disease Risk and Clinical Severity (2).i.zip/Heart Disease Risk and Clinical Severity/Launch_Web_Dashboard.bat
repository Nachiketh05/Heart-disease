@echo off
title Heart Disease Web Dashboard Launcher
cd /d "%~dp0"
echo =================================================================
echo   LAUNCHING HEART DISEASE CLINICAL DASHBOARD (PORT 8050)...
echo =================================================================
start http://localhost:8050
python serve_dashboard.py
pause
