% =========================================================================
% MASTER APPLICATION LAUNCHER: run_app.m
% =========================================================================
% Academic Project: Heart Disease Risk & Clinical Severity Assessment
% Framework: Multilayer Perceptron, Hopfield Network, Fuzzy Logic, Genetic Algorithm
%
% Usage:
%   In MATLAB command prompt, type:
%       run_app
%
% This single launcher:
%   1. Checks environment and dataset dependencies.
%   2. Runs zero-leakage preprocessing if cleveland_preprocessed.mat is absent.
%   3. Trains/computes models if integrated_system_results.mat is absent.
%   4. Launches the full professional multi-tab MATLAB GUI application.
% =========================================================================

clear; clc; close all;

fprintf('=================================================================\n');
fprintf('  HEART DISEASE RISK & CLINICAL SEVERITY ASSESSMENT APP LAUNCHER \n');
fprintf('=================================================================\n\n');

% 1. Dataset Verification
rawFile = 'processed.cleveland.data';
if ~isfile(rawFile)
    error('Dataset file "%s" not found in workspace directory: %s', rawFile, pwd);
end

% 2. Preprocessed Data Verification
matFile = 'cleveland_preprocessed.mat';
if ~isfile(matFile)
    fprintf('[INFO] Preprocessed data not found. Executing zero-leakage pipeline...\n');
    main_preprocessing_pipeline;
else
    fprintf('[OK] Preprocessed data detected: "%s".\n', matFile);
end

% 3. Integrated Models Verification
resFile = 'integrated_system_results.mat';
if ~isfile(resFile)
    fprintf('[INFO] Model artifacts not found. Training integrated CI engines...\n');
    main_integrated_system;
else
    fprintf('[OK] Trained CI models detected: "%s".\n', resFile);
end

% 4. Launch Native GUI Application
fprintf('\n[LAUNCH] Starting Native MATLAB Graphical Application...\n');
heart_disease_matlab_gui;

fprintf('=================================================================\n');
fprintf('Application successfully launched. Close window to terminate.\n');
fprintf('=================================================================\n');
