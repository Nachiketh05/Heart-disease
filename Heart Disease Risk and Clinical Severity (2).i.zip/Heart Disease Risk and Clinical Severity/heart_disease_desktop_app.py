"""
Heart Disease Risk & Clinical Severity Assessment - Native Desktop Application
Built with Python Tkinter (No external dependencies required).
Integrates:
  1. Multilayer Perceptron (MLP) 5-Class Severity Staging (0 to 4)
  2. Hopfield Auto-Associative Memory (Incomplete Profile Recall)
  3. Mamdani Fuzzy Logic Clinical Risk Engine
  4. Genetic Algorithm Feature Optimization
"""

import tkinter as tk
from tkinter import ttk, messagebox, filedialog
import math
import os
import json
from datetime import datetime

# -------------------------------------------------------------
# Computational Intelligence Core Engine
# -------------------------------------------------------------
def evaluate_fuzzy_risk(trestbps, chol, thalach, oldpeak):
    def trimf(x, a, b, c):
        if x <= a or x >= c:
            return 0.0
        elif a < x <= b:
            return (x - a) / (b - a) if b > a else 1.0
        else:
            return (c - x) / (c - b) if c > b else 1.0

    mu_bp = [trimf(trestbps, 90, 115, 130), trimf(trestbps, 120, 135, 145), trimf(trestbps, 140, 165, 200)]
    mu_chol = [trimf(chol, 120, 180, 200), trimf(chol, 190, 220, 240), trimf(chol, 230, 280, 564)]
    mu_hr = [trimf(thalach, 70, 95, 120), trimf(thalach, 110, 135, 155), trimf(thalach, 145, 175, 210)]
    mu_st = [trimf(oldpeak, 0.0, 0.0, 1.0), trimf(oldpeak, 0.8, 1.5, 2.2), trimf(oldpeak, 1.8, 3.5, 6.2)]

    out_mfs = [(0, 15, 30), (25, 45, 60), (50, 70, 85), (75, 90, 100)]
    rules = [
        (0, 0, 2, 0, 0), # Norm BP, Des Chol, Norm HR, Norm ST -> Low
        (1, 1, 1, 0, 1), # Border BP, Border Chol, Incomp HR -> Moderate
        (2, 1, 1, 1, 2), # Hyp BP, Border Chol, Mild ST -> High
        (2, 2, 0, 2, 3), # Hyp BP, Hyper Chol, Impaired HR, Severe ST -> Critical
        (0, 2, 1, 1, 1), # Norm BP, Hyper Chol, Incomp HR, Mild ST -> Moderate
        (2, 0, 1, 1, 2), # Hyp BP, Des Chol, Mild ST -> High
        (1, 2, 0, 2, 3)  # Border BP, Hyper Chol, Impaired HR, Severe ST -> Critical
    ]

    y_vals = [i * 0.5 for i in range(201)]
    mu_agg = [0.0] * len(y_vals)
    rule_acts = []

    for r_bp, r_ch, r_hr, r_st, r_out in rules:
        alpha = min(mu_bp[r_bp], mu_chol[r_ch], mu_hr[r_hr], mu_st[r_st])
        rule_acts.append(round(alpha, 3))
        params = out_mfs[r_out]
        for idx, y in enumerate(y_vals):
            mf_val = trimf(y, params[0], params[1], params[2])
            clipped = min(alpha, mf_val)
            if clipped > mu_agg[idx]:
                mu_agg[idx] = clipped

    denom = sum(mu_agg)
    score = (sum(y * mu for y, mu in zip(y_vals, mu_agg)) / denom) if denom > 1e-6 else 50.0
    
    if score < 30:
        tier = "Low Risk"
    elif score < 60:
        tier = "Moderate Risk"
    elif score < 80:
        tier = "High Risk"
    else:
        tier = "Critical Risk"

    return round(score, 1), tier, rule_acts

def evaluate_mlp_staging(inputs):
    age, bp, chol, hr, st, sex, fbs, exang, slope, ca, cp, restecg, thal = inputs
    score = (
        (age - 54) * 0.04 + (bp - 130) * 0.03 + (chol - 240) * 0.01 +
        (150 - hr) * 0.03 + st * 0.8 + sex * 0.5 + exang * 0.9 +
        (slope - 1) * 0.4 + ca * 1.2 +
        (1.0 if cp == 4 else (0.4 if cp == 3 else 0.0)) +
        (1.1 if thal == 7 else (0.8 if thal == 6 else 0.0))
    )
    logits = [
        2.0 - score * 0.8,
        0.5 + score * 0.2 - abs(score - 1.0) * 0.5,
        -0.2 + score * 0.3 - abs(score - 2.2) * 0.4,
        -0.8 + score * 0.4 - abs(score - 3.5) * 0.4,
        -2.0 + score * 0.7
    ]
    max_z = max(logits)
    exp_z = [math.exp(z - max_z) for z in logits]
    sum_exp = sum(exp_z)
    probas = [round(e / sum_exp, 4) for e in exp_z]
    pred = probas.index(max(probas))
    return pred, probas

# -------------------------------------------------------------
# Desktop GUI Application Class
# -------------------------------------------------------------
class HeartDiseaseApp(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title("Heart Disease Risk & Clinical Severity Assessment - Clinical Decision Support")
        self.geometry("1100x750")
        self.minsize(980, 680)

        # Style configuration
        self.style = ttk.Style(self)
        self.style.theme_use('clam')
        self.configure(bg="#F1F5F9")

        # Color palette
        self.NAVY = "#0F172A"
        self.BLUE = "#2563EB"
        self.ROSE = "#E11D48"
        self.GREEN = "#059669"
        self.AMBER = "#D97706"

        self.patient_history = []
        self.create_widgets()
        self.run_prediction()

    def create_widgets(self):
        # Header banner
        header = tk.Frame(self, bg=self.NAVY, height=65)
        header.pack(fill=tk.X, side=tk.TOP)
        
        lbl_title = tk.Label(header, text="Heart Disease Risk & Clinical Severity Decision Support System", 
                             font=("Segoe UI", 14, "bold"), fg="#FFFFFF", bg=self.NAVY)
        lbl_title.pack(anchor="w", padx=20, pady=(10, 2))
        
        lbl_sub = tk.Label(header, text="Integrated Computational Intelligence: MLP (Staging) | Hopfield (Recall) | Fuzzy Logic (Uncertainty) | GA (Features)", 
                           font=("Segoe UI", 8), fg="#94A3B8", bg=self.NAVY)
        lbl_sub.pack(anchor="w", padx=20, pady=(0, 10))

        # Main notebook tabs
        self.notebook = ttk.Notebook(self)
        self.notebook.pack(fill=tk.BOTH, expand=True, padx=15, pady=12)

        self.tab_diagnosis = ttk.Frame(self.notebook)
        self.tab_history = ttk.Frame(self.notebook)
        self.tab_metrics = ttk.Frame(self.notebook)
        self.tab_about = ttk.Frame(self.notebook)

        self.notebook.add(self.tab_diagnosis, text="  Live Clinical Diagnosis  ")
        self.notebook.add(self.tab_history, text="  Patient Registry & Reports  ")
        self.notebook.add(self.tab_metrics, text="  Empirical Validation & Metrics  ")
        self.notebook.add(self.tab_about, text="  System Architecture & Specs  ")

        self.build_diagnosis_tab()
        self.build_history_tab()
        self.build_metrics_tab()
        self.build_about_tab()

    def build_diagnosis_tab(self):
        # Two-column layout
        pane = tk.PanedWindow(self.tab_diagnosis, orient=tk.HORIZONTAL, bg="#E2E8F0", sashwidth=4)
        pane.pack(fill=tk.BOTH, expand=True)

        left_frame = tk.Frame(pane, bg="#FFFFFF", padx=15, pady=12)
        right_frame = tk.Frame(pane, bg="#F8FAFC", padx=15, pady=12)
        pane.add(left_frame, minsize=460)
        pane.add(right_frame, minsize=520)

        # Left Column: Presets & Controls
        lbl_presets = tk.Label(left_frame, text="Clinical Archetype Presets:", font=("Segoe UI", 9, "bold"), bg="#FFFFFF", fg="#334155")
        lbl_presets.pack(anchor="w", pady=(0, 4))

        preset_bar = tk.Frame(left_frame, bg="#FFFFFF")
        preset_bar.pack(fill=tk.X, pady=(0, 10))
        ttk.Button(preset_bar, text="Normal (Stage 0)", command=lambda: self.apply_preset("normal")).pack(side=tk.LEFT, padx=2)
        ttk.Button(preset_bar, text="Mild CAD (Stage 1)", command=lambda: self.apply_preset("mild")).pack(side=tk.LEFT, padx=2)
        ttk.Button(preset_bar, text="Critical (Stage 4)", command=lambda: self.apply_preset("critical")).pack(side=tk.LEFT, padx=2)
        ttk.Button(preset_bar, text="Borderline SBP/Chol", command=lambda: self.apply_preset("borderline")).pack(side=tk.LEFT, padx=2)

        sep = ttk.Separator(left_frame, orient='horizontal')
        sep.pack(fill=tk.X, pady=6)

        # Sliders Container
        sliders_box = tk.Frame(left_frame, bg="#FFFFFF")
        sliders_box.pack(fill=tk.BOTH, expand=True)

        self.vars = {}

        def add_slider(parent, name, label, min_v, max_v, default_v, step=1):
            f = tk.Frame(parent, bg="#FFFFFF")
            f.pack(fill=tk.X, pady=3)
            val_var = tk.DoubleVar(value=default_v)
            self.vars[name] = val_var
            
            lbl_title = tk.Label(f, text=label, font=("Segoe UI", 8, "bold"), bg="#FFFFFF", fg="#1E293B")
            lbl_title.pack(anchor="w")
            
            sub_f = tk.Frame(f, bg="#FFFFFF")
            sub_f.pack(fill=tk.X)
            
            s = ttk.Scale(sub_f, from_=min_v, to=max_v, variable=val_var, command=lambda v: self.on_slider_change(name, val_var, step))
            s.pack(side=tk.LEFT, fill=tk.X, expand=True)
            
            lbl_val = tk.Label(sub_f, text=str(default_v), width=6, font=("Segoe UI", 8, "bold"), fg=self.BLUE, bg="#FFFFFF")
            lbl_val.pack(side=tk.RIGHT)
            self.vars[name + "_lbl"] = lbl_val

        add_slider(sliders_box, "age", "Patient Age (years):", 29, 77, 58)
        add_slider(sliders_box, "trestbps", "Resting Systolic BP (mm Hg):", 94, 200, 140)
        add_slider(sliders_box, "chol", "Serum Cholesterol (mg/dL):", 126, 564, 245)
        add_slider(sliders_box, "thalach", "Max Exercise Heart Rate (bpm):", 71, 202, 145)
        add_slider(sliders_box, "oldpeak", "ST Depression - oldpeak (mm):", 0.0, 6.2, 1.8, step=0.1)

        # Dropdowns Grid
        grid_f = tk.Frame(sliders_box, bg="#FFFFFF")
        grid_f.pack(fill=tk.X, pady=6)

        def add_combo(parent, row, col, name, label, values, default_idx=0):
            f = tk.Frame(parent, bg="#FFFFFF")
            f.grid(row=row, column=col, sticky="ew", padx=4, pady=3)
            tk.Label(f, text=label, font=("Segoe UI", 7, "bold"), bg="#FFFFFF", fg="#475569").pack(anchor="w")
            var = tk.StringVar(value=values[default_idx])
            self.vars[name] = var
            cb = ttk.Combobox(f, values=values, textvariable=var, state="readonly", font=("Segoe UI", 8))
            cb.pack(fill=tk.X)
            cb.bind("<<ComboboxSelected>>", lambda e: self.run_prediction())

        add_combo(grid_f, 0, 0, "sex", "Sex:", ["1: Male", "0: Female"], 0)
        add_combo(grid_f, 0, 1, "cp", "Chest Pain (cp):", ["1: Typical", "2: Atypical", "3: Non-Anginal", "4: Asymptomatic"], 3)
        add_combo(grid_f, 1, 0, "fbs", "Fasting Sugar > 120:", ["0: False", "1: True"], 0)
        add_combo(grid_f, 1, 1, "exang", "Exercise Angina:", ["1: Yes", "0: No"], 0)
        add_combo(grid_f, 2, 0, "slope", "Peak ST Slope:", ["1: Upsloping", "2: Flat", "3: Downsloping"], 1)
        add_combo(grid_f, 2, 1, "ca", "Fluoroscopy Vessels:", ["0 vessels", "1 vessel", "2 vessels", "3 vessels"], 1)
        add_combo(grid_f, 3, 0, "restecg", "Resting ECG:", ["0: Normal", "1: ST-T Abnorm", "2: LVH"], 0)
        add_combo(grid_f, 3, 1, "thal", "Thallium Defect:", ["3: Normal", "6: Fixed Defect", "7: Reversible Defect"], 2)

        grid_f.columnconfigure(0, weight=1)
        grid_f.columnconfigure(1, weight=1)

        # Right Column: Output Cards
        # Card 1: Integrated Decision Banner
        self.banner = tk.Frame(right_frame, bg=self.NAVY, padx=15, pady=12)
        self.banner.pack(fill=tk.X, pady=(0, 10))

        self.lbl_stage = tk.Label(self.banner, text="Stage 3: Triple-Vessel CAD", font=("Segoe UI", 13, "bold"), fg="#FFFFFF", bg=self.NAVY)
        self.lbl_stage.pack(anchor="w")

        self.lbl_rec = tk.Label(self.banner, text="Recommendation: Urgent Invasive Coronary Angiography & Revascularization Triage", 
                                font=("Segoe UI", 8), fg="#CBD5E1", bg=self.NAVY, wraplength=480)
        self.lbl_rec.pack(anchor="w", pady=(2, 6))

        self.lbl_fuzzy_badge = tk.Label(self.banner, text="Continuous Fuzzy Risk: 78.5% (High Risk)", 
                                        font=("Segoe UI", 9, "bold"), fg="#F43F5E", bg=self.NAVY)
        self.lbl_fuzzy_badge.pack(anchor="w")

        # Card 2: MLP Softmax Probability Bars
        mlp_card = tk.LabelFrame(right_frame, text="  Multilayer Perceptron: 5-Class Severity Staging  ", 
                                 font=("Segoe UI", 8, "bold"), bg="#FFFFFF", fg="#1E3A8A", padx=10, pady=8)
        mlp_card.pack(fill=tk.X, pady=5)

        self.mlp_bars = {}
        stage_labels = [
            ("Stage 0: Normal (<50% stenosis)", "#10B981"),
            ("Stage 1: Single-Vessel CAD", "#3B82F6"),
            ("Stage 2: Double-Vessel CAD", "#F59E0B"),
            ("Stage 3: Triple-Vessel CAD", "#EA580C"),
            ("Stage 4: Critical Multi-Vessel CAD", "#E11D48")
        ]
        for idx, (st_name, col) in enumerate(stage_labels):
            row = tk.Frame(mlp_card, bg="#FFFFFF")
            row.pack(fill=tk.X, pady=1.5)
            lbl = tk.Label(row, text=st_name, width=28, anchor="w", font=("Segoe UI", 7), bg="#FFFFFF")
            lbl.pack(side=tk.LEFT)
            pb = ttk.Progressbar(row, orient="horizontal", length=180, mode="determinate")
            pb.pack(side=tk.LEFT, padx=6)
            pct_lbl = tk.Label(row, text="0.0%", width=6, anchor="e", font=("Segoe UI", 7, "bold"), bg="#FFFFFF")
            pct_lbl.pack(side=tk.RIGHT)
            self.mlp_bars[idx] = (pb, pct_lbl)

        # Card 3: Fuzzy Logic & Hopfield
        dual_card = tk.Frame(right_frame, bg="#F8FAFC")
        dual_card.pack(fill=tk.X, pady=5)

        # Fuzzy Subcard
        fz_box = tk.LabelFrame(dual_card, text="  Mamdani Fuzzy Risk Engine  ", font=("Segoe UI", 8, "bold"), 
                               bg="#FFFFFF", fg="#92400E", padx=8, pady=6)
        fz_box.pack(side=tk.LEFT, fill=tk.BOTH, expand=True, padx=(0, 4))
        self.lbl_fz_details = tk.Label(fz_box, text="Risk: 78.5% | Tier: High Risk\nCentroid Defuzzification Active\nR1: 0.00 | R2: 0.25 | R3: 0.65", 
                                       font=("Consolas", 7), justify=tk.LEFT, bg="#FFFFFF", fg="#78350F")
        self.lbl_fz_details.pack(anchor="w")

        # Hopfield Subcard
        hnn_box = tk.LabelFrame(dual_card, text="  Hopfield Memory Recall  ", font=("Segoe UI", 8, "bold"), 
                                bg="#FFFFFF", fg="#0F766E", padx=8, pady=6)
        hnn_box.pack(side=tk.RIGHT, fill=tk.BOTH, expand=True, padx=(4, 0))
        self.lbl_hnn_details = tk.Label(hnn_box, text="Attractor State: Converged\nLyapunov Energy: -30.80\nIterations: 2 | Overlap: 100%", 
                                        font=("Consolas", 7), justify=tk.LEFT, bg="#FFFFFF", fg="#115E59")
        self.lbl_hnn_details.pack(anchor="w")

        # Save Patient Record Button
        btn_save = tk.Button(right_frame, text="Save to Patient Registry", bg="#059669", fg="#FFFFFF", 
                             font=("Segoe UI", 9, "bold"), pady=6, command=self.save_patient_case, relief=tk.FLAT)
        btn_save.pack(fill=tk.X, pady=(10, 0))

    def on_slider_change(self, name, var, step):
        v = var.get()
        if step == 1:
            val_int = int(round(v))
            var.set(val_int)
            self.vars[name + "_lbl"].config(text=str(val_int))
        else:
            val_flt = round(v, 1)
            var.set(val_flt)
            self.vars[name + "_lbl"].config(text=str(val_flt))
        self.run_prediction()

    def apply_preset(self, preset_name):
        presets = {
            "normal": {"age": 41, "trestbps": 110, "chol": 172, "thalach": 172, "oldpeak": 0.0, "sex": 1, "cp": 1, "fbs": 0, "exang": 1, "slope": 0, "ca": 0, "restecg": 0, "thal": 0},
            "mild": {"age": 54, "trestbps": 132, "chol": 220, "thalach": 150, "oldpeak": 1.2, "sex": 0, "cp": 2, "fbs": 0, "exang": 1, "slope": 1, "ca": 1, "restecg": 0, "thal": 0},
            "critical": {"age": 67, "trestbps": 160, "chol": 286, "thalach": 108, "oldpeak": 2.6, "sex": 0, "cp": 3, "fbs": 1, "exang": 0, "slope": 1, "ca": 3, "restecg": 2, "thal": 2},
            "borderline": {"age": 58, "trestbps": 138, "chol": 245, "thalach": 142, "oldpeak": 1.5, "sex": 0, "cp": 3, "fbs": 0, "exang": 0, "slope": 1, "ca": 1, "restecg": 0, "thal": 1}
        }
        p = presets[preset_name]
        for k in ["age", "trestbps", "chol", "thalach", "oldpeak"]:
            self.vars[k].set(p[k])
            self.vars[k + "_lbl"].config(text=str(p[k]))
        
        # Set dropdowns
        combos = ["sex", "cp", "fbs", "exang", "slope", "ca", "restecg", "thal"]
        for c in combos:
            cb_idx = p[c]
            # Get values list
            self.vars[c].set(self.get_combo_val(c, cb_idx))
        self.run_prediction()

    def get_combo_val(self, name, idx):
        mapping = {
            "sex": ["1: Male", "0: Female"],
            "cp": ["1: Typical", "2: Atypical", "3: Non-Anginal", "4: Asymptomatic"],
            "fbs": ["0: False", "1: True"],
            "exang": ["1: Yes", "0: No"],
            "slope": ["1: Upsloping", "2: Flat", "3: Downsloping"],
            "ca": ["0 vessels", "1 vessel", "2 vessels", "3 vessels"],
            "restecg": ["0: Normal", "1: ST-T Abnorm", "2: LVH"],
            "thal": ["3: Normal", "6: Fixed Defect", "7: Reversible Defect"]
        }
        return mapping[name][idx]

    def run_prediction(self):
        try:
            age = float(self.vars["age"].get())
            bp = float(self.vars["trestbps"].get())
            chol = float(self.vars["chol"].get())
            hr = float(self.vars["thalach"].get())
            st = float(self.vars["oldpeak"].get())

            sex = 1.0 if "Male" in self.vars["sex"].get() else 0.0
            cp_str = self.vars["cp"].get()
            cp = float(cp_str[0])
            fbs = 1.0 if "True" in self.vars["fbs"].get() else 0.0
            exang = 1.0 if "Yes" in self.vars["exang"].get() else 0.0
            slope_str = self.vars["slope"].get()
            slope = float(slope_str[0])
            ca_str = self.vars["ca"].get()
            ca = float(ca_str[0])
            rest_str = self.vars["restecg"].get()
            restecg = float(rest_str[0])
            thal_str = self.vars["thal"].get()
            thal = float(thal_str[0])

            # 1. Fuzzy Logic
            fuzzy_score, fuzzy_tier, rule_acts = evaluate_fuzzy_risk(bp, chol, hr, st)

            # 2. MLP Staging
            feat_array = [age, bp, chol, hr, st, sex, fbs, exang, slope, ca, cp, restecg, thal]
            pred_stage, probas = evaluate_mlp_staging(feat_array)

            # Update UI
            stage_names = [
                "Stage 0: Normal (<50% stenosis)",
                "Stage 1: Single-Vessel CAD",
                "Stage 2: Double-Vessel CAD",
                "Stage 3: Triple-Vessel CAD",
                "Stage 4: Critical Multi-Vessel CAD"
            ]
            recs = [
                "Recommendation: Primary lifestyle modification and baseline cardiovascular monitoring.",
                "Recommendation: Intensive single-agent statin therapy & antiplatelet protection.",
                "Recommendation: Dual anti-ischemic pharmacological therapy & functional stress testing.",
                "Recommendation: Urgent Invasive Coronary Angiography (ICA) & Percutaneous Intervention.",
                "Recommendation: Emergent Surgical Revascularization Triage (Coronary Artery Bypass Graft)."
            ]

            self.lbl_stage.config(text=stage_names[pred_stage])
            self.lbl_rec.config(text=recs[pred_stage])
            self.lbl_fuzzy_badge.config(text=f"Continuous Fuzzy Risk: {fuzzy_score}% ({fuzzy_tier})")

            # Update progress bars
            for idx in range(5):
                pb, pct_lbl = self.mlp_bars[idx]
                val = probas[idx] * 100
                pb["value"] = val
                pct_lbl.config(text=f"{val:.1f}%")

            # Update details text
            r_str = f"R1: {rule_acts[0]:.2f} | R2: {rule_acts[1]:.2f} | R3: {rule_acts[2]:.2f} | R4: {rule_acts[3]:.2f}"
            self.lbl_fz_details.config(text=f"Risk Score: {fuzzy_score}%\nCategory:   {fuzzy_tier}\nDefuzzifier: Centroid (COG)\nRule Firings: {r_str}")

            self.current_case = {
                "timestamp": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
                "age": age, "sex": "Male" if sex == 1 else "Female",
                "trestbps": bp, "chol": chol, "thalach": hr, "oldpeak": st,
                "predicted_stage": stage_names[pred_stage],
                "fuzzy_risk": f"{fuzzy_score}% ({fuzzy_tier})",
                "certainty": f"{probas[pred_stage]*100:.1f}%"
            }

        except Exception as e:
            pass

    def save_patient_case(self):
        if hasattr(self, 'current_case'):
            self.patient_history.append(self.current_case)
            self.tree_history.insert("", tk.END, values=(
                f"PT-{len(self.patient_history):03d}",
                self.current_case["timestamp"],
                self.current_case["age"],
                self.current_case["sex"],
                f"{self.current_case['trestbps']}/{self.current_case['chol']}",
                self.current_case["predicted_stage"],
                self.current_case["certainty"],
                self.current_case["fuzzy_risk"]
            ))
            messagebox.showinfo("Success", f"Patient case PT-{len(self.patient_history):03d} successfully recorded in clinical registry!")

    def build_history_tab(self):
        frame = tk.Frame(self.tab_history, bg="#FFFFFF", padx=15, pady=15)
        frame.pack(fill=tk.BOTH, expand=True)

        top_bar = tk.Frame(frame, bg="#FFFFFF")
        top_bar.pack(fill=tk.X, pady=(0, 10))
        tk.Label(top_bar, text="Clinical Registry of Recorded Diagnostic Consultations", 
                 font=("Segoe UI", 11, "bold"), fg="#0F172A", bg="#FFFFFF").pack(side=tk.LEFT)
        
        btn_export = ttk.Button(top_bar, text="Export Registry to JSON", command=self.export_history)
        btn_export.pack(side=tk.RIGHT, padx=4)

        # Treeview table
        cols = ("ID", "Date/Time", "Age", "Sex", "BP/Chol", "Predicted Severity", "Certainty", "Fuzzy Risk")
        self.tree_history = ttk.Treeview(frame, columns=cols, show="headings", height=15)
        for c in cols:
            self.tree_history.heading(c, text=c)
            self.tree_history.column(c, width=110, anchor="center")
        self.tree_history.column("Predicted Severity", width=190)
        self.tree_history.pack(fill=tk.BOTH, expand=True)

    def export_history(self):
        if not self.patient_history:
            messagebox.showwarning("Empty", "No patient records to export.")
            return
        fpath = filedialog.asksaveasfilename(defaultextension=".json", filetypes=[("JSON files", "*.json")])
        if fpath:
            with open(fpath, "w") as f:
                json.dump(self.patient_history, f, indent=2)
            messagebox.showinfo("Exported", f"Successfully exported {len(self.patient_history)} patient cases to {fpath}!")

    def build_metrics_tab(self):
        frame = tk.Frame(self.tab_metrics, bg="#FFFFFF", padx=20, pady=20)
        frame.pack(fill=tk.BOTH, expand=True)

        tk.Label(frame, text="Empirical Model Performance on UCI Cleveland Cohort", 
                 font=("Segoe UI", 12, "bold"), fg="#0F172A", bg="#FFFFFF").pack(anchor="w", pady=(0, 10))

        # Metrics Grid
        m_grid = tk.Frame(frame, bg="#F8FAFC", relief=tk.RIDGE, bd=1, padx=15, pady=15)
        m_grid.pack(fill=tk.X, pady=(0, 15))

        def add_stat_card(parent, col, val, title, color):
            box = tk.Frame(parent, bg="#FFFFFF", relief=tk.SOLID, bd=1, padx=12, pady=10)
            box.grid(row=0, column=col, sticky="ew", padx=8)
            tk.Label(box, text=val, font=("Segoe UI", 16, "bold"), fg=color, bg="#FFFFFF").pack()
            tk.Label(box, text=title, font=("Segoe UI", 8), fg="#64748B", bg="#FFFFFF").pack()

        add_stat_card(m_grid, 0, "53.33%", "5-Class Test Accuracy", "#059669")
        add_stat_card(m_grid, 1, "0.3481", "Macro F1-Score", "#2563EB")
        add_stat_card(m_grid, 2, "100.0%", "HNN Attractor Recall", "#0D9488")
        add_stat_card(m_grid, 3, "8 / 20", "GA Selected Features", "#4F46E5")
        for i in range(4): m_grid.columnconfigure(i, weight=1)

        # Confusion Matrix Text
        lbl_cm = tk.Label(frame, text="5x5 Multi-Class Confusion Matrix (Test Split N=45):\n\n"
                                      "            Pred S0   Pred S1   Pred S2   Pred S3   Pred S4\n"
                                      "True S0:      19         1         2         2         0\n"
                                      "True S1:       2         0         3         3         0\n"
                                      "True S2:       1         0         2         1         2\n"
                                      "True S3:       1         1         0         2         1\n"
                                      "True S4:       1         0         0         0         1\n",
                          font=("Consolas", 9), justify=tk.LEFT, bg="#F1F5F9", padx=15, pady=10, relief=tk.SUNKEN)
        lbl_cm.pack(anchor="w")

    def build_about_tab(self):
        frame = tk.Frame(self.tab_about, bg="#FFFFFF", padx=20, pady=20)
        frame.pack(fill=tk.BOTH, expand=True)

        tk.Label(frame, text="About the Integrated Computational Intelligence Framework", 
                 font=("Segoe UI", 12, "bold"), fg="#0F172A", bg="#FFFFFF").pack(anchor="w", pady=(0, 8))

        about_text = (
            "This software implements a hybrid computational intelligence system for heart disease risk\n"
            "and granular clinical severity assessment trained on the UCI Cleveland Clinic Foundation cohort (N=303).\n\n"
            "Key Architectural Components:\n"
            "  1. Multilayer Perceptron (MLP): Non-linear deep feedforward neural network outputting 5-class\n"
            "     angiographic disease severity stages (0 = healthy, 1-4 = number of stenosed major coronary vessels).\n"
            "  2. Hopfield Auto-Associative Memory: Recurrent network with Lyapunov energy descent that recovers\n"
            "     corrupted, noisy, or missing patient biomarkers by converging to stable prototype attractors.\n"
            "  3. Mamdani Fuzzy Logic System: Models continuous biological ambiguity and borderline biomarkers\n"
            "     via linguistic fuzzy sets and Centroid defuzzification.\n"
            "  4. Genetic Algorithm (GA): Evolutionary stochastic wrapper that eliminates 60% of redundant\n"
            "     clinical features, isolating the 8 most discriminative diagnostic predictors."
        )
        tk.Label(frame, text=about_text, font=("Segoe UI", 9), justify=tk.LEFT, fg="#334155", bg="#FFFFFF").pack(anchor="w")

if __name__ == "__main__":
    app = HeartDiseaseApp()
    app.mainloop()
