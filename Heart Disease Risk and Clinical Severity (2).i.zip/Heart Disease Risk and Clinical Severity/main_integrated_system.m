% =========================================================================
% MASTER INTEGRATED SYSTEM PIPELINE
% =========================================================================
% Academic Project: Heart Disease Risk & Clinical Severity Assessment
% Modules:
%   1. Data Preprocessing & Anti-Leakage Tensors (cleveland_preprocessed.mat)
%   2. Hopfield Neural Network (HNN) - Incomplete Profile Recovery
%   3. Genetic Algorithm (GA) - 13-Gene Evolutionary Biomarker Optimization
%   4. Multilayer Perceptron (MLP) - Multi-Class Severity Staging (0 to 4)
%   5. Hybrid Architectures: Hybrid 1 (Fuzzy+MLP) & Hybrid 2 (GA+MLP)
%   6. Mamdani Fuzzy Logic System (FLS) - Continuous Epistemic Risk Assessment
%   7. Integrated Decision Engine & Performance Synthesis
% =========================================================================

clear; clc; close all;

fprintf('=================================================================\n');
fprintf('  HEART DISEASE RISK & CLINICAL SEVERITY ASSESSMENT (MATLAB)     \n');
fprintf('  Integrated Computational Intelligence Framework Execution     \n');
fprintf('=================================================================\n\n');

%% 1. LOAD PREPROCESSED DATASETS
matFile = 'cleveland_preprocessed.mat';
if ~isfile(matFile)
    fprintf('[INFO] Preprocessed file not found. Running preprocessing pipeline...\n');
    main_preprocessing_pipeline;
end

load(matFile);
fprintf('[DATA] Loaded preprocessed splits from "%s":\n', matFile);
fprintf('       Train: [%d x %d] | Val: [%d x %d] | Test: [%d x %d]\n\n', ...
        size(X_train, 1), size(X_train, 2), ...
        size(X_val, 1), size(X_val, 2), ...
        size(X_test, 1), size(X_test, 2));

%% 2. MODULE 1: HOPFIELD NEURAL NETWORK (HNN) ATTRACTOR RECALL
fprintf('-----------------------------------------------------------------\n');
fprintf('MODULE 1: HOPFIELD NEURAL NETWORK (HNN) ATTRACTOR RECALL\n');
fprintf('-----------------------------------------------------------------\n');

% Compute prototypical bipolar clinical vectors across the 5 severity categories
classes = 0:4;
numC = numel(classes);
prototypes = zeros(numC, size(X_train, 2));
for c = 1:numC
    idx = (y_train == classes(c));
    meanVec = mean(X_train(idx, :), 1);
    prototypes(c, :) = sign(meanVec); % Bipolar conversion {-1, +1}
    prototypes(c, prototypes(c, :) == 0) = 1;
end

% Train Hopfield Auto-Associative Matrix
hnnModel = hopfieldNetwork('train', prototypes);

% Validation test: Invert 30% bits on prototype 4 (Severe CAD) to simulate corruption
rng(42);
testPatientBipolar = prototypes(4, :)';
[corruptedQuery, corruptMask] = hopfieldNetwork('corrupt', testPatientBipolar, 0.30, 'flip');

[recallResult, hnnStepDetails] = hopfieldNetwork('recall', hnnModel, corruptedQuery, 50);
overlap = mean(recallResult.recalled == testPatientBipolar);

fprintf('  HNN Recall Simulation on Corrupted Patient Profile:\n');
fprintf('  - Corrupted Bits:     %d / %d (%.1f%%)\n', sum(corruptMask), hnnModel.M, 100*mean(corruptMask));
fprintf('  - Convergence Status: %s in %d sweeps (%d neuron updates)\n', ...
        char(matlab.lang.OnOffSwitchState(recallResult.converged)), recallResult.epochs, recallResult.totalNeuronUpdates);
fprintf('  - Initial Energy:     %.4f | Final Lyapunov Energy: %.4f\n', ...
        recallResult.initialEnergy, recallResult.finalEnergy);
fprintf('  - Prototype Overlap:  %.2f%% reconstruction accuracy\n', 100*overlap);
fprintf('  - Attractor Basin:    Prototype %d (Overlap = %.2f)\n\n', ...
        recallResult.bestMatchingPrototype, recallResult.bestMatchingOverlap);

%% 3. MODULE 2: GENETIC ALGORITHM (GA) 13-GENE FEATURE SELECTION
fprintf('-----------------------------------------------------------------\n');
fprintf('MODULE 2: GENETIC ALGORITHM (GA) 13-GENE FEATURE OPTIMIZATION\n');
fprintf('-----------------------------------------------------------------\n');

gaOpts = struct();
gaOpts.popSize = 30;
gaOpts.generations = 35;
gaOpts.pCrossover = 0.85;
gaOpts.tournamentK = 3;
gaOpts.verbose = false;

gaResult = geneticAlgorithm(X_train, y_train, X_val, y_val, gaOpts);

fprintf('  GA Optimization Results (Validation Objective):\n');
fprintf('  - Baseline All 13 Features: Val Macro-F1 = %.4f | Fitness = %.4f\n', ...
        gaResult.allFeaturesBaseline.valMacroF1, gaResult.allFeaturesBaseline.fitness);
fprintf('  - Optimized Clinical Subset: %d / 13 attributes selected\n', gaResult.numSelectedFeatures);
fprintf('  - Selected Clinical Names:  [ %s]\n', sprintf('%s ', gaResult.selectedFeatureNames{:}));
fprintf('  - Encoded Matrix Columns:   [ %s]\n', sprintf('%d ', gaResult.selectedEncodedColumns));
fprintf('  - Best Validation Fitness:  %.4f (Val Macro-F1: %.4f)\n\n', ...
        gaResult.bestFitness, gaResult.valMacroF1);

%% 4. MODULE 3 & 4: HYBRID COMPUTATIONAL INTELLIGENCE BENCHMARKING
% Benchmarks Baseline MLP vs Hybrid 1 (Fuzzy+MLP) vs Hybrid 2 (GA+MLP)
hybridResults = hybridModelSuite(X_train, y_train, X_val, y_val, X_test, y_test, ...
                                prepModel, trainTableClean, valTableClean, testTableClean, gaResult);

baseMetrics    = hybridResults.baseline.metrics;
hybrid1Metrics = hybridResults.hybrid1.metrics;
hybrid2Metrics = hybridResults.hybrid2.metrics;

%% 5. MODULE 5: MAMDANI FUZZY LOGIC CLINICAL RISK ESTIMATION
fprintf('-----------------------------------------------------------------\n');
fprintf('MODULE 5: MAMDANI FUZZY LOGIC INFERENCE (EXACT HAND-VERIFIED MATH)\n');
fprintf('-----------------------------------------------------------------\n');

fis = fuzzyLogicSystem('build');

% Extract the 4 continuous variables from test table
rawTestInputs = [testTableClean.trestbps, testTableClean.chol, ...
                 testTableClean.thalach, testTableClean.oldpeak];

[fuzzyRiskScores, fuzzyRiskTiers, fzDetails] = fuzzyLogicSystem('evaluate', fis, rawTestInputs);

fprintf('  Fuzzy Inference Summary on Test Cohort (N=%d):\n', size(rawTestInputs, 1));
fprintf('  - Mean Continuous Risk Score: %.1f%% (Min: %.1f%%, Max: %.1f%%)\n', ...
        mean(fuzzyRiskScores), min(fuzzyRiskScores), max(fuzzyRiskScores));
fprintf('  - Risk Tier Breakdown: Low=%d | Moderate=%d | High=%d | Critical=%d\n\n', ...
        sum(strcmp(fuzzyRiskTiers, 'Low Risk')), ...
        sum(strcmp(fuzzyRiskTiers, 'Moderate Risk')), ...
        sum(strcmp(fuzzyRiskTiers, 'High Risk')), ...
        sum(strcmp(fuzzyRiskTiers, 'Critical Risk')));

% Detailed intermediate calculation trace for Patient #1
pat1Inputs = rawTestInputs(1, :);
pat1Details = fuzzyLogicSystem('explain', fis, pat1Inputs);

fprintf('  Sample Intermediate Calculation Trace (Patient #01 Test Cohort):\n');
fprintf('  - Inputs: BP=%.0f mmHg, Chol=%.0f mg/dL, HR=%.0f bpm, ST=%.1f mm\n', ...
        pat1Inputs(1), pat1Inputs(2), pat1Inputs(3), pat1Inputs(4));
fprintf('  - BP Memberships:   Normal=%.3f, Borderline=%.3f, Hypertensive=%.3f\n', ...
        pat1Details.last_mu_in1(1), pat1Details.last_mu_in1(2), pat1Details.last_mu_in1(3));
fprintf('  - Chol Memberships: Desirable=%.3f, Borderline=%.3f, Hyperchol=%.3f\n', ...
        pat1Details.last_mu_in2(1), pat1Details.last_mu_in2(2), pat1Details.last_mu_in2(3));
fprintf('  - Active Rules:     %d rules fired with alpha > 0\n', numel(pat1Details.activeRules));
fprintf('  - Centroid Math:    Numerator=%.4f, Denominator=%.4f => Risk = %.2f%%\n\n', ...
        pat1Details.last_cog_num, pat1Details.last_cog_den, fuzzyRiskScores(1));

%% 6. INTEGRATED DECISION SYNTHESIS & REPORTING
fprintf('=================================================================\n');
fprintf('             FINAL INTEGRATED PERFORMANCE EVALUATION             \n');
fprintf('=================================================================\n\n');

fprintf('Multi-Class Clinical Severity Breakdown (Baseline MLP, Test Cohort N=%d):\n', numel(y_test));
fprintf('%-10s | %-12s | %-12s | %-12s | %s\n', 'Category', 'Precision', 'Recall/Sens', 'F1-Score', 'Support');
fprintf('-------------------------------------------------------------------------\n');
stageNames = {'Stage 0 (No CAD)', 'Stage 1 (1 CAD)', 'Stage 2 (2 CAD)', 'Stage 3 (3 CAD)', 'Stage 4 (Crit CAD)'};
for c = 1:5
    supp = sum(y_test == (c-1));
    fprintf('%-10s | %-12.4f | %-12.4f | %-12.4f | %3d (%s)\n', ...
            sprintf('Stage %d', c-1), ...
            baseMetrics.classPrecision(c), ...
            baseMetrics.classRecall(c), ...
            baseMetrics.classF1(c), ...
            supp, stageNames{c});
end
fprintf('-------------------------------------------------------------------------\n');
fprintf('MACRO AVG  | %-12.4f | %-12.4f | %-12.4f | %3d Patients\n\n', ...
        baseMetrics.macroPrecision, baseMetrics.macroRecall, baseMetrics.macroF1, numel(y_test));

fprintf('5x5 Multi-Class Confusion Matrix (Rows = Ground Truth, Cols = Predicted):\n');
disp(baseMetrics.confusionMatrix);

% Display 5 Sample Patient Integrated Profiles
fprintf('-----------------------------------------------------------------\n');
fprintf('SAMPLE INTEGRATED PATIENT DIAGNOSTIC REPORTS (TEST COHORT):\n');
fprintf('-----------------------------------------------------------------\n');
for p = 1:min(5, numel(y_test))
    gt = y_test(p);
    pred = baseMetrics.predictions(p);
    prob = baseMetrics.probabilities(p, pred + 1);
    fRisk = fuzzyRiskScores(p);
    fTier = fuzzyRiskTiers{p};
    
    matchStr = 'CORRECT';
    if gt ~= pred, matchStr = 'MISMATCH'; end
    
    fprintf('Patient #%02d | True Stage: %d | Pred Stage: %d (Prob: %4.1f%%) | Fuzzy Risk: %4.1f%% (%-13s) [%s]\n', ...
            p, gt, pred, 100*prob, fRisk, fTier, matchStr);
end
fprintf('-----------------------------------------------------------------\n\n');

%% 7. SAVE EXECUTION RESULTS TO DISK
save('integrated_system_results.mat', ...
     'baseMetrics', 'hybridResults', 'hnnModel', 'fis', 'gaResult', ...
     'fuzzyRiskScores', 'fuzzyRiskTiers', 'prototypes');

fprintf('=================================================================\n');
fprintf('[SUCCESS] Execution completed successfully.\n');
fprintf('Results saved to "integrated_system_results.mat".\n');
fprintf('=================================================================\n');
