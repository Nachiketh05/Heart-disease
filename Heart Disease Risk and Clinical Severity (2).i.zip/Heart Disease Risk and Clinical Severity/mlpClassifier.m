function [result, varargout] = mlpClassifier(action, varargin)
% MLPCLASSIFIER Deep Multilayer Perceptron for multi-class CAD severity staging.
%
%   Usage:
%       model = mlpClassifier('train', X_train, y_train, X_val, y_val, opts)
%       [y_pred, probas, details] = mlpClassifier('predict', model, X_test)
%       metrics = mlpClassifier('evaluate', model, X_test, y_test)
%
%   Academic Context:
%       Maps clinical attributes to 5 discrete angiographic severity categories:
%       - Stage 0: Healthy (<50% coronary stenosis)
%       - Stage 1: Single-vessel coronary artery disease
%       - Stage 2: Double-vessel coronary artery disease
%       - Stage 3: Triple-vessel coronary artery disease
%       - Stage 4: Critical multi-vessel CAD / left-main occlusion
%
%   Mathematical Formulations:
%       - Linear forward step: Z^[l] = W^[l] * A^[l-1] + b^[l]
%       - Leaky ReLU activation: A^[l] = max(alpha * Z^[l-1], Z^[l-1]), alpha = 0.01
%       - Output Softmax: A^[L+1]_c = exp(Z^[L]_c - max(Z^[L])) / sum(exp(Z^[L]))
%       - Categorical Cross-Entropy Loss with L2 Regularization:
%         L = -1/B sum(y_c * log(A^[L+1]_c + eps)) + lambda / (2*N) * sum(||W^[l]||_F^2)
%       - Backward Gradient: dZ^[L] = A^[L+1] - Y_onehot
%         dW^[l] = (1/B) * dZ^[l] * (A^[l-1])' + (lambda/N) * W^[l]
%         db^[l] = (1/B) * sum(dZ^[l], 2)
%         dZ^[l-1] = (W^[l])' * dZ^[l] .* g'(Z^[l-1])
%       - Adam Optimizer: first (m) and second (v) moment bias-corrected updates

    switch lower(action)
        case 'train'
            X_train = varargin{1};
            y_train = varargin{2}(:);
            X_val   = varargin{3};
            y_val   = varargin{4}(:);
            
            if length(varargin) >= 5 && ~isempty(varargin{5})
                opts = varargin{5};
            else
                opts = struct();
            end
            
            % Hyperparameters
            hiddenDims = getFieldOrDefault(opts, 'hiddenDims', [64, 32]);
            epochs     = getFieldOrDefault(opts, 'epochs', 250);
            lr         = getFieldOrDefault(opts, 'learningRate', 0.005);
            lambda     = getFieldOrDefault(opts, 'l2Lambda', 0.001);
            batchSize  = getFieldOrDefault(opts, 'batchSize', 32);
            verbose    = getFieldOrDefault(opts, 'verbose', false);
            
            [nSamples, inputDim] = size(X_train);
            classes = 0:4;
            numClasses = numel(classes);
            
            % One-hot encode ground truth targets
            Y_train_oh = zeros(nSamples, numClasses);
            for c = 1:numClasses
                Y_train_oh(:, c) = double(y_train == classes(c));
            end
            
            % Layer dimensions: [D, H1, H2, ..., C]
            layerDims = [inputDim, hiddenDims, numClasses];
            numLayers = numel(layerDims) - 1;
            
            % He (Kaiming) Weight Initialization: std = sqrt(2 / n_in)
            rng(42); % Reproducible initialization
            W = cell(numLayers, 1);
            b = cell(numLayers, 1);
            for l = 1:numLayers
                inD = layerDims(l);
                outD = layerDims(l+1);
                stdv = sqrt(2.0 / inD);
                W{l} = randn(outD, inD) * stdv;
                b{l} = zeros(outD, 1);
            end
            
            % Adam optimizer moment trackers
            mW = cell(numLayers, 1); vW = cell(numLayers, 1);
            mb = cell(numLayers, 1); vb = cell(numLayers, 1);
            for l = 1:numLayers
                mW{l} = zeros(size(W{l})); vW{l} = zeros(size(W{l}));
                mb{l} = zeros(size(b{l})); vb{l} = zeros(size(b{l}));
            end
            beta1 = 0.9; beta2 = 0.999; epsAdam = 1e-8;
            t = 0;
            
            trainLossHistory = zeros(epochs, 1);
            valLossHistory   = zeros(epochs, 1);
            
            % Training Epochs
            for epoch = 1:epochs
                perm = randperm(nSamples);
                numBatches = ceil(nSamples / batchSize);
                epochLoss = 0;
                
                for batch = 1:numBatches
                    t = t + 1;
                    bIdx = perm((batch-1)*batchSize + 1 : min(batch*batchSize, nSamples));
                    Xb = X_train(bIdx, :)';    % [inD x B]
                    Yb = Y_train_oh(bIdx, :)'; % [numClasses x B]
                    B = size(Xb, 2);
                    
                    % Forward Pass
                    A = cell(numLayers + 1, 1);
                    Z = cell(numLayers, 1);
                    A{1} = Xb;
                    
                    for l = 1:numLayers-1
                        Z{l} = W{l} * A{l} + b{l};
                        A{l+1} = max(0.01 * Z{l}, Z{l}); % Leaky ReLU
                    end
                    
                    % Output layer with Softmax
                    Z{numLayers} = W{numLayers} * A{numLayers} + b{numLayers};
                    expZ = exp(Z{numLayers} - max(Z{numLayers}, [], 1));
                    A{numLayers+1} = expZ ./ sum(expZ, 1);
                    
                    % Cross-Entropy loss on batch
                    batchLoss = -sum(sum(Yb .* log(A{numLayers+1} + 1e-12))) / B;
                    epochLoss = epochLoss + batchLoss * B;
                    
                    % Backpropagation
                    dZ = A{numLayers+1} - Yb; % Softmax + Cross-Entropy gradient
                    
                    for l = numLayers:-1:1
                        dW = (1/B) * (dZ * A{l}') + (lambda / nSamples) * W{l};
                        db = (1/B) * sum(dZ, 2);
                        
                        if l > 1
                            dA_prev = W{l}' * dZ;
                            dZ = dA_prev .* ((Z{l-1} >= 0) + 0.01 * (Z{l-1} < 0));
                        end
                        
                        % Adam parameter updates
                        mW{l} = beta1 * mW{l} + (1 - beta1) * dW;
                        vW{l} = beta2 * vW{l} + (1 - beta2) * (dW .^ 2);
                        m_hat_W = mW{l} / (1 - beta1^t);
                        v_hat_W = vW{l} / (1 - beta2^t);
                        W{l} = W{l} - (lr ./ (sqrt(v_hat_W) + epsAdam)) .* m_hat_W;
                        
                        mb{l} = beta1 * mb{l} + (1 - beta1) * db;
                        vb{l} = beta2 * vb{l} + (1 - beta2) * (db .^ 2);
                        m_hat_b = mb{l} / (1 - beta1^t);
                        v_hat_b = vb{l} / (1 - beta2^t);
                        b{l} = b{l} - (lr ./ (sqrt(v_hat_b) + epsAdam)) .* m_hat_b;
                    end
                end
                
                trainLossHistory(epoch) = epochLoss / nSamples;
                
                % Compute validation loss
                if ~isempty(X_val)
                    [~, probaVal] = mlpForwardInternal(X_val, W, b, numLayers);
                    Y_val_oh = zeros(numel(y_val), numClasses);
                    for c = 1:numClasses
                        Y_val_oh(:, c) = double(y_val == classes(c));
                    end
                    valLossHistory(epoch) = -sum(sum(Y_val_oh .* log(probaVal + 1e-12))) / numel(y_val);
                end
                
                if verbose && mod(epoch, 25) == 0
                    fprintf('  [Epoch %3d/%3d] Train Loss: %.4f | Val Loss: %.4f\n', ...
                            epoch, epochs, trainLossHistory(epoch), valLossHistory(epoch));
                end
            end
            
            model = struct();
            model.W = W;
            model.b = b;
            model.layerDims = layerDims;
            model.numLayers = numLayers;
            model.classes = classes;
            model.inputDim = inputDim;
            model.trainLossHistory = trainLossHistory;
            model.valLossHistory = valLossHistory;
            result = model;
            
        case 'predict'
            model = varargin{1};
            X = varargin{2};
            [predClasses, probas, details] = mlpForwardInternal(X, model.W, model.b, model.numLayers);
            result = predClasses;
            if nargout > 1
                varargout{1} = probas;
            end
            if nargout > 2
                varargout{2} = details;
            end
            
        case 'evaluate'
            model = varargin{1};
            X = varargin{2};
            y_true = varargin{3}(:);
            
            [y_pred, probas, fwdDetails] = mlpForwardInternal(X, model.W, model.b, model.numLayers);
            
            % Compute comprehensive multi-class metrics
            classes = model.classes;
            numC = numel(classes);
            N = numel(y_true);
            
            % 5x5 Confusion Matrix: CM(r, c) = count of true class r, predicted class c
            cm = zeros(numC, numC);
            for i = 1:N
                r = y_true(i) + 1;
                c = y_pred(i) + 1;
                cm(r, c) = cm(r, c) + 1;
            end
            
            % Per-class breakdown: TP, FP, FN, TN
            tp = zeros(numC, 1);
            fp = zeros(numC, 1);
            fn = zeros(numC, 1);
            tn = zeros(numC, 1);
            prec = zeros(numC, 1);
            rec  = zeros(numC, 1);
            spec = zeros(numC, 1);
            f1   = zeros(numC, 1);
            
            for c = 1:numC
                tp(c) = cm(c, c);
                fp(c) = sum(cm(:, c)) - tp(c);
                fn(c) = sum(cm(c, :)) - tp(c);
                tn(c) = sum(cm(:)) - (tp(c) + fp(c) + fn(c));
                
                % Precision = TP / (TP + FP)
                if (tp(c) + fp(c)) > 0
                    prec(c) = tp(c) / (tp(c) + fp(c));
                else
                    prec(c) = 0.0;
                end
                
                % Recall / Sensitivity = TP / (TP + FN)
                if (tp(c) + fn(c)) > 0
                    rec(c) = tp(c) / (tp(c) + fn(c));
                else
                    rec(c) = 0.0;
                end
                
                % Specificity = TN / (TN + FP)
                if (tn(c) + fp(c)) > 0
                    spec(c) = tn(c) / (tn(c) + fp(c));
                else
                    spec(c) = 0.0;
                end
                
                % F1-Score = 2 * (Prec * Rec) / (Prec + Rec)
                if (prec(c) + rec(c)) > 0
                    f1(c) = 2.0 * (prec(c) * rec(c)) / (prec(c) + rec(c));
                else
                    f1(c) = 0.0;
                end
            end
            
            % Macro-Averaged Metrics
            acc = sum(tp) / N;
            macroPrec = mean(prec);
            macroRec  = mean(rec);
            macroSpec = mean(spec);
            macroF1   = mean(f1);
            
            metrics = struct();
            metrics.accuracy = acc;
            metrics.macroPrecision = macroPrec;
            metrics.macroRecall = macroRec;
            metrics.macroSpecificity = macroSpec;
            metrics.macroF1 = macroF1;
            metrics.confusionMatrix = cm;
            metrics.predictions = y_pred;
            metrics.probabilities = probas;
            
            % Intermediate calculation arrays for inspection
            metrics.intermediate = struct();
            metrics.intermediate.TP = tp;
            metrics.intermediate.FP = fp;
            metrics.intermediate.FN = fn;
            metrics.intermediate.TN = tn;
            metrics.intermediate.classPrecision = prec;
            metrics.intermediate.classRecall = rec;
            metrics.intermediate.classSpecificity = spec;
            metrics.intermediate.classF1 = f1;
            metrics.intermediate.support = sum(cm, 2);
            metrics.intermediate.fwdDetails = fwdDetails;
            
            % Backwards compatibility convenience fields
            metrics.classPrecision = prec;
            metrics.classRecall = rec;
            metrics.classF1 = f1;
            
            result = metrics;
            
        otherwise
            error('Unknown action: %s. Valid actions: ''train'', ''predict'', ''evaluate''.', action);
    end
end

%% Feedforward Engine with Complete Layer-by-Layer Outputs
function [predClasses, probas, details] = mlpForwardInternal(X, W, b, numLayers)
    nSamples = size(X, 1);
    A = cell(numLayers + 1, 1);
    Z = cell(numLayers, 1);
    
    A{1} = X'; % [D x N]
    
    for l = 1:numLayers-1
        Z{l} = W{l} * A{l} + repmat(b{l}, 1, nSamples);
        A{l+1} = max(0.01 * Z{l}, Z{l}); % Leaky ReLU
    end
    
    % Output layer linear logits
    Z{numLayers} = W{numLayers} * A{numLayers} + repmat(b{numLayers}, 1, nSamples);
    
    % Numerically stable Softmax
    Z_shift = Z{numLayers} - max(Z{numLayers}, [], 1);
    expZ = exp(Z_shift);
    probas = (expZ ./ sum(expZ, 1))'; % [nSamples x numClasses]
    
    [~, maxIdx] = max(probas, [], 2);
    predClasses = maxIdx - 1; % Convert 1-indexed to 0-indexed (0 to 4)
    
    details = struct();
    details.linearActivations_Z = Z;
    details.postActivations_A = A;
    details.logits = Z{numLayers}';
    details.probas = probas;
    details.predictedClasses = predClasses;
end

function val = getFieldOrDefault(s, field, defaultVal)
    if isfield(s, field)
        val = s.(field);
    else
        val = defaultVal;
    end
end
