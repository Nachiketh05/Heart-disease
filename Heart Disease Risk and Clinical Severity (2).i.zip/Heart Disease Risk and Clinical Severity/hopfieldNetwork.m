function [modelOrResult, varargout] = hopfieldNetwork(action, varargin)
% HOPFIELDNETWORK Auto-associative memory network for clinical profile recall.
%
%   Usage:
%       model = hopfieldNetwork('train', prototypes)
%       [recallResult, stepDetails] = hopfieldNetwork('recall', model, queryPattern, maxIter)
%       [corrupted, mask] = hopfieldNetwork('corrupt', pattern, noiseRatio, noiseType)
%       energy = hopfieldNetwork('energy', model, state)
%
%   Academic Context:
%       Recovers corrupted, incomplete, or partially missing clinical profiles
%       by converging to stable prototype attractor basins via monotonic
%       Lyapunov energy minimization.
%
%   Mathematical Rigor:
%       - Hebbian outer-product learning: W = (1/M) * sum(xi^mu * (xi^mu)')
%       - Diagonal zeroing (w_ii = 0) eliminates self-feedback loops
%       - Asynchronous state updates: s_i^(t+1) = sgn(h_i) with state retention for h_i = 0
%       - Lyapunov Energy: E(s) = -0.5 * s' * W * s
%       - Monotonic convergence guarantee: Delta E = -(s_i^(t+1) - s_i^(t)) * h_i <= 0
%       - Overlap coefficient: m^mu = (1/M) * (s' * xi^mu) in [-1, +1]

    switch lower(action)
        case 'train'
            prototypes = varargin{1}; % Matrix [P x M], values in {-1, +1}
            [P, M] = size(prototypes);
            
            % Validate bipolar encoding {-1, +1}
            invalidVals = prototypes ~= 1 & prototypes ~= -1;
            if any(invalidVals(:))
                error('Hopfield Error: Prototype patterns must be strictly bipolar {-1, +1}.');
            end
            
            % Hebbian Learning Matrix: W = (1 / M) * (Xi' * Xi)
            W = (1.0 / M) * (prototypes' * prototypes);
            
            % Enforce zero-diagonal constraint: w_ii = 0
            W = W - diag(diag(W));
            
            % Verify matrix symmetry: W == W'
            assert(norm(W - W', 'fro') < 1e-10, 'Hopfield Error: Weight matrix must be strictly symmetric!');
            
            model = struct();
            model.W = W;
            model.M = M;
            model.P = P;
            model.prototypes = prototypes;
            model.trainedDate = datestr(now);
            
            modelOrResult = model;
            
        case 'recall'
            model = varargin{1};
            queryPattern = varargin{2}(:); % Bipolar column vector [M x 1]
            if length(varargin) >= 3 && ~isempty(varargin{3})
                maxIter = varargin{3};
            else
                maxIter = 50;
            end
            
            W = model.W;
            M = model.M;
            P = model.P;
            s = queryPattern;
            
            % Compute initial energy and overlaps
            initialEnergy = -0.5 * (s' * W * s);
            initialOverlaps = (1.0 / M) * (model.prototypes * s);
            initialHamming  = 0.5 * (M - (model.prototypes * s));
            
            stepHistory = [];
            epochEnergy = zeros(maxIter, 1);
            
            converged = false;
            epoch = 0;
            totalSteps = 0;
            
            while ~converged && epoch < maxIter
                epoch = epoch + 1;
                s_epoch_start = s;
                
                % Randomized asynchronous update sweep over all M neurons
                updateOrder = randperm(M);
                
                for idx = 1:M
                    totalSteps = totalSteps + 1;
                    i = updateOrder(idx);
                    
                    % Local activation field: h_i = sum_j (w_ij * s_j)
                    h_i = W(i, :) * s;
                    s_old = s(i);
                    
                    % Threshold activation with state retention for h_i == 0
                    if h_i > 0
                        s(i) = 1;
                    elseif h_i < 0
                        s(i) = -1;
                    else
                        s(i) = s_old; % Retain previous state
                    end
                    s_new = s(i);
                    
                    % Lyapunov Energy Delta: Delta E = -(s_new - s_old) * h_i
                    deltaE = -(s_new - s_old) * h_i;
                    currentE = -0.5 * (s' * W * s);
                    
                    % Record step details if requested
                    if nargout > 1 || totalSteps <= 200
                        stepRec = struct('step', totalSteps, 'epoch', epoch, ...
                                         'neuron', i, 'localField', h_i, ...
                                         's_old', s_old, 's_new', s_new, ...
                                         'deltaE', deltaE, 'energy', currentE);
                        stepHistory = [stepHistory; stepRec];
                    end
                end
                
                epochEnergy(epoch) = -0.5 * (s' * W * s);
                
                % Check convergence: no neuron changed state in the entire sweep
                if isequal(s, s_epoch_start)
                    converged = true;
                end
            end
            
            finalEnergy = -0.5 * (s' * W * s);
            finalOverlaps = (1.0 / M) * (model.prototypes * s);
            finalHamming  = 0.5 * (M - (model.prototypes * s));
            
            [maxOverlap, bestProtoIdx] = max(finalOverlaps);
            
            result = struct();
            result.query = queryPattern;
            result.recalled = s;
            result.converged = converged;
            result.epochs = epoch;
            result.totalNeuronUpdates = totalSteps;
            result.initialEnergy = initialEnergy;
            result.finalEnergy = finalEnergy;
            result.energyTrajectory = epochEnergy(1:epoch);
            result.initialOverlaps = initialOverlaps;
            result.finalOverlaps = finalOverlaps;
            result.initialHamming = initialHamming;
            result.finalHamming = finalHamming;
            result.bestMatchingPrototype = bestProtoIdx;
            result.bestMatchingOverlap = maxOverlap;
            
            modelOrResult = result;
            if nargout > 1
                varargout{1} = stepHistory;
            end
            
        case 'corrupt'
            pattern = varargin{1}(:);
            if length(varargin) >= 2 && ~isempty(varargin{2})
                noiseRatio = varargin{2};
            else
                noiseRatio = 0.25;
            end
            if length(varargin) >= 3 && ~isempty(varargin{3})
                noiseType = varargin{3};
            else
                noiseType = 'flip';
            end
            
            M = numel(pattern);
            numCorrupt = max(1, round(noiseRatio * M));
            corruptIndices = randperm(M, numCorrupt);
            
            corrupted = pattern;
            mask = false(M, 1);
            mask(corruptIndices) = true;
            
            switch lower(noiseType)
                case 'flip'
                    % Bit inversion: +1 -> -1, -1 -> +1
                    corrupted(mask) = -corrupted(mask);
                case 'zero'
                    % Erasure / missing value: set to neutral 0
                    corrupted(mask) = 0;
            end
            
            modelOrResult = corrupted;
            if nargout > 1
                varargout{1} = mask;
            end
            
        case 'energy'
            model = varargin{1};
            s = varargin{2}(:);
            modelOrResult = -0.5 * (s' * model.W * s);
            
        otherwise
            error('Unknown action: %s. Valid actions: ''train'', ''recall'', ''corrupt'', ''energy''.', action);
    end
end
