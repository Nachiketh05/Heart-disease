function prepModel = fitPreprocessing(trainTable, normMethod)
% FITPREPROCESSING Fits all imputation statistics, encodings, and normalization
% strictly and exclusively on the training partition to prevent data leakage.
%
%   prepModel = fitPreprocessing(trainTable, normMethod)
%
%   Inputs:
%       trainTable - Training partition table of the Cleveland dataset
%       normMethod - 'zscore' (default) for zero-mean/unit-variance standardization
%                    'minmax' for scaling into [0, 1] (ideal for Fuzzy Logic)
%
%   Output:
%       prepModel  - Struct containing all fitted transformation parameters
%
%   Anti-Leakage Guarantee:
%       In statistical machine learning, computing imputation values (e.g. mean,
%       median) or scaling parameters (mean, standard deviation) across the full
%       dataset before splitting leaks test set distributions into training.
%       This function strictly isolates parameter calculation to the training fold.

    if nargin < 2 || isempty(normMethod)
        normMethod = 'zscore';
    end

    prepModel = struct();
    prepModel.normMethod = normMethod;
    prepModel.fitDate = datestr(now);
    prepModel.nTrainSamples = height(trainTable);

    % =========================================================================
    % 1. Missing-Value Imputation Parameters (Fitted on Training Data Only)
    % =========================================================================
    % Attribute 'ca' (Number of major vessels colored by fluoroscopy, 0-3):
    % Discrete anatomical count. Mode or Median preserves integer anatomy.
    ca_clean = trainTable.ca(~isnan(trainTable.ca));
    prepModel.ca_impute_val = median(ca_clean); % Median is robust to extreme outliers

    % Attribute 'thal' (Thallium scintigraphy heart defect: 3=Normal, 6=Fixed, 7=Reversible):
    % Multi-class nominal category. Mode represents most frequent clinical baseline.
    thal_clean = trainTable.thal(~isnan(trainTable.thal));
    prepModel.thal_impute_val = mode(thal_clean);

    fprintf('[FIT] Imputation values computed from Train fold:\n');
    fprintf('      - ca (vessels colored) median: %.0f\n', prepModel.ca_impute_val);
    fprintf('      - thal (heart scan) mode:      %.0f\n', prepModel.thal_impute_val);

    % =========================================================================
    % 2. Categorical Variable Definitions & Fixed Level Mapping
    % =========================================================================
    % Storing fixed levels prevents mismatch if a validation/test fold lacks a category
    prepModel.catCols = struct();
    prepModel.catCols.cp_levels      = [1, 2, 3, 4];    % 1=Typical, 2=Atypical, 3=Non-anginal, 4=Asymptomatic
    prepModel.catCols.restecg_levels = [0, 1, 2];       % 0=Normal, 1=ST-T abnormality, 2=LVH
    prepModel.catCols.thal_levels    = [3, 6, 7];       % 3=Normal, 6=Fixed defect, 7=Reversible defect
    prepModel.catCols.slope_levels   = [1, 2, 3];       % 1=Upsloping, 2=Flat, 3=Downsloping

    % Binary attributes (already {0, 1}):
    prepModel.binaryCols = {'sex', 'fbs', 'exang'};

    % =========================================================================
    % 3. Numerical Continuous Variables Normalization Statistics
    % =========================================================================
    prepModel.continuousCols = {'age', 'trestbps', 'chol', 'thalach', 'oldpeak'};
    prepModel.nCont = numel(prepModel.continuousCols);

    prepModel.stats = struct();
    for i = 1:prepModel.nCont
        colName = prepModel.continuousCols{i};
        rawVals = trainTable.(colName);

        % Z-Score parameters: mu and sigma
        prepModel.stats.(colName).mean = mean(rawVals, 'omitnan');
        prepModel.stats.(colName).std  = std(rawVals, 'omitnan');
        if prepModel.stats.(colName).std < 1e-8
            prepModel.stats.(colName).std = 1.0; % Prevent division by zero
        end

        % Min-Max parameters: min and max
        prepModel.stats.(colName).min = min(rawVals);
        prepModel.stats.(colName).max = max(rawVals);
        if abs(prepModel.stats.(colName).max - prepModel.stats.(colName).min) < 1e-8
            prepModel.stats.(colName).range = 1.0;
        else
            prepModel.stats.(colName).range = prepModel.stats.(colName).max - prepModel.stats.(colName).min;
        end
    end

    % Also compute scaling stats for ordinal variables ('slope', 'ca')
    prepModel.ordinalCols = {'slope', 'ca'};
    for i = 1:numel(prepModel.ordinalCols)
        colName = prepModel.ordinalCols{i};
        rawVals = trainTable.(colName);
        if isfield(prepModel, [colName, '_impute_val'])
            rawVals(isnan(rawVals)) = prepModel.([colName, '_impute_val']);
        end
        prepModel.stats.(colName).mean = mean(rawVals);
        prepModel.stats.(colName).std  = max(std(rawVals), 1e-8);
        prepModel.stats.(colName).min  = min(rawVals);
        prepModel.stats.(colName).max  = max(rawVals);
        prepModel.stats.(colName).range = max(prepModel.stats.(colName).max - prepModel.stats.(colName).min, 1e-8);
    end

    % Record class distribution of target in training
    prepModel.targetClasses = [0, 1, 2, 3, 4];
    prepModel.trainClassCounts = histcounts(trainTable.num, -0.5:1:4.5);

    fprintf('[FIT] Completed fitting preprocessing pipeline on %d training records.\n', prepModel.nTrainSamples);
end
