function [trainIdx, valIdx, testIdx] = stratifiedSplit(y, trainRatio, valRatio, testRatio, seed)
% STRATIFIEDSPLIT Partitions data into Stratified Train, Validation, and Test sets.
%
%   [trainIdx, valIdx, testIdx] = stratifiedSplit(y, trainRatio, valRatio, testRatio, seed)
%
%   Inputs:
%       y          - Discrete/categorical target vector (e.g. 0, 1, 2, 3, 4)
%       trainRatio - Proportion of samples allocated to training (default: 0.70)
%       valRatio   - Proportion allocated to validation (default: 0.15)
%       testRatio  - Proportion allocated to testing (default: 0.15)
%       seed       - Random number generator seed for exact reproducibility (default: 42)
%
%   Outputs:
%       trainIdx   - Logical or integer indices of training samples
%       valIdx     - Logical or integer indices of validation samples
%       testIdx    - Logical or integer indices of testing samples
%
%   Clinical/Statistical Rationale:
%       The Cleveland dataset exhibits pronounced class imbalance across its 5
%       disease severity categories (e.g., Category 4 has only 13 cases, 4.3%).
%       A simple random split risks allocating zero or disproportionately few
%       severe cases to validation or test sets. Stratified sampling preserves
%       the exact class proportion in every fold.

    if nargin < 2 || isempty(trainRatio), trainRatio = 0.70; end
    if nargin < 3 || isempty(valRatio),   valRatio   = 0.15; end
    if nargin < 4 || isempty(testRatio),  testRatio  = 0.15; end
    if nargin < 5 || isempty(seed),       seed       = 42;   end

    % Normalize ratios if their sum is slightly off due to float rounding
    totalRatio = trainRatio + valRatio + testRatio;
    trainRatio = trainRatio / totalRatio;
    valRatio   = valRatio / totalRatio;
    testRatio  = testRatio / totalRatio;

    rng(seed);

    nSamples = numel(y);
    classes = unique(y);
    nClasses = numel(classes);

    trainMask = false(nSamples, 1);
    valMask   = false(nSamples, 1);
    testMask  = false(nSamples, 1);

    for c = 1:nClasses
        classVal = classes(c);
        idx = find(y == classVal);
        nClassSamples = numel(idx);

        % Permute indices within this class reproducibly
        idxShuffled = idx(randperm(nClassSamples));

        % Compute allocation counts with minimum guarantees for rare classes
        nTrain = round(trainRatio * nClassSamples);
        nVal   = round(valRatio * nClassSamples);

        % Ensure at least 1 sample in validation and testing if class count allows
        if nClassSamples >= 3
            nTrain = min(nTrain, nClassSamples - 2);
            nVal   = max(1, min(nVal, nClassSamples - nTrain - 1));
        end
        nTest = nClassSamples - nTrain - nVal;

        % Slice indices
        trainIdxClass = idxShuffled(1:nTrain);
        valIdxClass   = idxShuffled((nTrain + 1):(nTrain + nVal));
        testIdxClass  = idxShuffled((nTrain + nVal + 1):end);

        trainMask(trainIdxClass) = true;
        valMask(valIdxClass)     = true;
        testMask(testIdxClass)   = true;
    end

    trainIdx = find(trainMask);
    valIdx   = find(valMask);
    testIdx  = find(testMask);

    % Sanity checks
    assert(isempty(intersect(trainIdx, valIdx)), 'Data Leakage: Overlap detected between Train and Val!');
    assert(isempty(intersect(trainIdx, testIdx)), 'Data Leakage: Overlap detected between Train and Test!');
    assert(isempty(intersect(valIdx, testIdx)), 'Data Leakage: Overlap detected between Val and Test!');
    assert(numel(trainIdx) + numel(valIdx) + numel(testIdx) == nSamples, 'Index partition sum mismatch!');

    fprintf('[SPLIT] Stratified Split (Seed=%d): Train=%d (%.1f%%), Val=%d (%.1f%%), Test=%d (%.1f%%)\n', ...
            seed, numel(trainIdx), 100*numel(trainIdx)/nSamples, ...
            numel(valIdx), 100*numel(valIdx)/nSamples, ...
            numel(testIdx), 100*numel(testIdx)/nSamples);
end
